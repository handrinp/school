package regex;

public class NoCralf {
  public static void main(String[] args) {
    System.out.println("\t");
  }  
}
