public class WhyThisCralf {
/*
\n should never be used, not even in a comment.
 */
}
