public class Cralf1 {
  public static void main(String[] args) {
    System.out.print("There's no present like the time.\r\n");
  }
}
