public class Cralf3 {
  public static void main(String[] args) {
    System.out.print("uno\r\nloves\ndos");
  }
}
