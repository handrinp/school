package foo;

public class BoolOkay {
  public static void main(String[] args) {
    while (true) {
      System.out.println("a");
    }  

    while (!false) {
      System.out.println("b");
    }  

    if ("true" == "false") {
      System.out.println("c");
    }
  }
}
