class Bools {
  public static void main(String[] args) {
    if (args.length > 0 == true) {
      //...
    }
    if (false == args[0].equals("-n")) {
      //...
    }
  }
}
