import bad.foo.get.outta.Here;

import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import java.util.Scanner;
import org.apache.http.Request;


import edu.uwec.cs330.Regexercise;
import javax.swing.*;

public class Export1 {
  public static void main(String[] args) {
    int important = 13;
    System.out.println(important);
  }  
}
