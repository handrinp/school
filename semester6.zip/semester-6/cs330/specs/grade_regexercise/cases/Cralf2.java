public class Cralf2 {
  public static void main(String[] args) {
    System.out.print("uno\r\n");
    System.out.print("dos\r\n");
    System.out.print("tres\r\n");
    System.out.print("cuatro\r\n");
    System.out.print("cinco\r\n");
    System.out.print("seis\r\n");
    System.out.print("siete\r\n");
  }
}
