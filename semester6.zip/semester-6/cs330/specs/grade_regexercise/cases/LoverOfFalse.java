public class LoverOfFalse {
  public LoverOfFalse() {
  }

  public String toString() {
    boolean b;
    b = 5 > 7 == true;
    b = 5 > 7 != true;
    b = 5 > 7 == false;
    b = 5 > 7 != false;
    b = true == 5 > 7;
    b = true != 5 > 7;
    b = false == 5 > 7;
    b = false != 5 > 7;
  }
}
