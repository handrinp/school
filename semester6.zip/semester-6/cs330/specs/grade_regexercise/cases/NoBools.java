public class NoBools {
  public static void main(String[] args) {
    boolean b;
    if (b = true) {
      System.out.println("This is okay. Assignment.");
    }
  }
}
