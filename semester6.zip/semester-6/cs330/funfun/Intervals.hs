module Intervals where

within :: Integer -> (Integer,Integer) -> Bool
within n (min,max) = n >= min && n <= max

withins :: Integer -> [(Integer,Integer)] -> [(Integer,Integer)]
withins = filter . within

isFree :: Integer -> [(Integer,Integer)] -> Bool
isFree n = (==) [] . withins n

freeBeyond :: [(Integer,Integer)] -> Integer
freeBeyond = (+1) . maximum . map snd

tern :: Bool -> a -> a -> a
tern c t f = if c then t else f

firstFree :: Integer -> [(Integer,Integer)] -> Integer
firstFree n [] = n
firstFree n list = tern (v >= n) v n
    where v = freeBeyond list

