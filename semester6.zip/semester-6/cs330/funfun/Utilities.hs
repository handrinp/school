module Utilities where

import Data.List(foldl', scanl', group, isInfixOf)
import GHC.Exts(sortWith)

froto :: [a] -> [(a,a)]
froto [] = []
froto (x:[]) = []
froto (x:y:ys) = (x,y):froto (y:ys)

nearness :: (Integer,Integer) -> Integer
nearness (a,b) = abs $ a - b

frotoByNearness :: [Integer] -> [(Integer,Integer)]
frotoByNearness = sortWith nearness . froto

nearestPair :: [Integer] -> (Integer,Integer)
nearestPair = head . frotoByNearness

mapButLast :: (a -> a) -> [a] -> [a]
mapButLast f list = (map f $ init list) ++ [last list]

implode :: (Show a) => String -> [a] -> String
implode sep = foldl' (++) "" . mapButLast (flip (++) sep) . map show

normspace :: String -> String
normspace = foldl' (++) "" . map (\s -> if isInfixOf "  " s then " " else s) . group

data Direction = North | South | East | West deriving (Eq, Show)

move1 :: (Int,Int) -> Direction -> (Int,Int)
move1 (x,y) North = (x,y+1)
move1 (x,y) South = (x,y-1)
move1 (x,y) East =  (x+1,y)
move1 (x,y) West =  (x-1,y)

moveN :: (Int,Int) -> [Direction] -> (Int,Int)
moveN = foldl' move1

intermoves :: (Int,Int) -> [Direction] -> [(Int,Int)]
intermoves = scanl' move1

