module BullsAndCows where

import System.Environment(getArgs)
import System.Random.Shuffle(shuffleM)

bulls :: String -> String -> String
bulls target guess = [x | (x,y) <- zip target guess, x == y]

nonbulls :: String -> String -> (String,String)
nonbulls target guess = unzip [(x,y) | (x,y) <- zip target guess, x /= y]

cows :: String -> String -> String
cows target guess = filter (\x -> elem x nb1) nb2
    where (nb1,nb2) = nonbulls target guess

score :: String -> String -> (Int,Int)
score target guess = (length b, length c)
    where b = bulls target guess
          c = cows target guess

game :: String -> IO ()
game target = do
    -- prompt player for guess
    putStr "Guess: "
    -- read guess
    guess <- getLine
    -- score guess
    let (b,c) = score target guess
    putStrLn $ "Bulls: " ++ (show b) ++ " | Cows: " ++ (show c)
    -- exit if score is (n,0)
    if (b == (length target))
        then return ()
        else do
            game target

randomTarget :: Int -> IO String
randomTarget len = do
    randomNumbers <- shuffleM ['0'..'9']
    return $ take len randomNumbers

main :: IO ()
main = do
    lenStr <- getArgs
    let len = read (lenStr !! 0)
    target <- randomTarget len
    game target

