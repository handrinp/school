module MindReader where

import Data.Bits(testBit, bit)
import Data.Char
import Data.List(foldl')

intsWithBit :: Int -> Int -> [Int]
intsWithBit max index = [x | x <- [0..max], testBit x index]

binaryToDecimal :: String -> Int
binaryToDecimal str = foldl' (\n c -> n + n + (if (c == '1') then 1 else 0)) 0 str

decimalToBinary' :: Int -> String
decimalToBinary' n
    | n == 0       = ""
    | mod n 2 == 0 = '0':decimalToBinary' (div n 2)
    | otherwise    = '1':decimalToBinary' (div n 2)

decimalToBinary :: Int -> String
decimalToBinary n
    | n == 0    = "0"
    | otherwise = reverse $ decimalToBinary' n

nbits :: Int -> Int
nbits n = length $ decimalToBinary n

promptForBit :: Int -> Int -> IO Int
promptForBit max index = do
    putStrLn ""
    putStrLn $ show $ intsWithBit max index
    putStr "Is your number in this list? y/[n]? "
    answer <- getLine
    return (if answer == "y" then 1 else 0)

main :: IO ()
main = do
    putStr "What's your favorite upper bound? "
    maxStr <- getLine
    let max = read maxStr
    putStrLn ""
    putStrLn $ "Think of a number in [1, " ++ maxStr ++ "]. But don't tell me. I will read your mind!"
    responses <- mapM (promptForBit max) [0..(nbits max - 1)]
    let guess = binaryToDecimal $ reverse $ map (\c -> if (c == 1) then '1' else '0') responses
    putStrLn ""
    putStrLn $ "Your number is " ++ show guess ++ "."
    return ()

