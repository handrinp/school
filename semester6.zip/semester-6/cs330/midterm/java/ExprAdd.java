public class ExprAdd extends Expr {
    private Expr lhs;
    private Expr rhs;

    public ExprAdd(Expr lhs, Expr rhs) {
        this.lhs = lhs;
        this.rhs = rhs;
    }
    
    public ExprInt evaluate() {
        return new ExprInt(lhs.evaluate().toInt() + rhs.evaluate().toInt());
    }
}
