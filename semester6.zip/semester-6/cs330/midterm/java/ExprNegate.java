public class ExprNegate extends Expr {
    private Expr operand;

    public ExprNegate(Expr operand) {
        this.operand = operand;
    }

    public ExprInt evaluate() {
        return new ExprInt(-operand.evaluate().toInt());
    }
}
