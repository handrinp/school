public abstract class Expr {
    public abstract ExprInt evaluate();
}
