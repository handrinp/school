public class ExprInt extends Expr {
    private int val;

    public ExprInt(int val) {
        this.val = val;
    }

    public ExprInt evaluate() {
        return new ExprInt(val);
    }

    public int toInt() {
        return val;
    }
}
