public class Main {
    public static void main(String[] args) {
        Expr e = new ExprAdd(new ExprInt(7),
                             new ExprNegate(new ExprMultiply(new ExprInt(5),
                                                             new ExprInt(2))));
        System.out.println(e.evaluate().toInt());
    }
}
