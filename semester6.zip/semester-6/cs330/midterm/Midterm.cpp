#include <iostream>

class ExprInt;

class Expr {
public:
	virtual ~Expr() {}
	virtual ExprInt evaluate()=0;
};

class ExprInt : public Expr {
private: int _val;
public:
	ExprInt(int val) : _val(val) {}
	virtual ~ExprInt() {};
	ExprInt evaluate() {return ExprInt(_val);}
	const int toInt() {return _val;}
};

class ExprNegate : public Expr {
private: Expr *_operand;
public:
	ExprNegate(Expr *operand) : _operand(operand) {}
	~ExprNegate() {delete _operand;}
	ExprInt evaluate() {return ExprInt(-_operand->evaluate().toInt());}
};

class ExprAdd : public Expr {
private: Expr *_lhs; Expr *_rhs;
public:
	ExprAdd(Expr *lhs, Expr *rhs) : _lhs(lhs), _rhs(rhs) {}
	~ExprAdd() {delete _lhs; delete _rhs;}
	ExprInt evaluate() {return ExprInt(_lhs->evaluate().toInt() + _rhs->evaluate().toInt());}
};

class ExprMultiply : public Expr {
private: Expr *_lhs; Expr *_rhs;
public:
	ExprMultiply(Expr *lhs, Expr *rhs) : _lhs(lhs), _rhs(rhs) {}
	~ExprMultiply() {delete _lhs; delete _rhs;}
	ExprInt evaluate() {return ExprInt(_lhs->evaluate().toInt() * _rhs->evaluate().toInt());}
};

int main() {
	Expr *e = new ExprAdd(new ExprInt(7), new ExprNegate(new ExprMultiply(new ExprInt(5), new ExprInt(2))));
	std::cout << e->evaluate().toInt() << std::endl;
	return 0;
}
