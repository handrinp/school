package wasd;

public class Player {
    private World world;
    private double fov;
    private Vector2 position;
    private Vector2 lookAt;

    public Player(World world, double fov) {
        this.world = world;
        this.fov = fov;
        position = world.getStart();
        lookAt = world.getLookAt();
    }

    public double getFieldOfView() {
        return fov;
    }

    public Vector2 getPosition() {
        return position;
    }

    public Vector2 getLookAt() {
        return lookAt;
    }

    public Vector2 getRight() {
        return lookAt.rotate(-90);
    }

    public void rotate(double deg) {
        lookAt = lookAt.rotate(deg);
    }

    public void advance(double dist) {
        position = position.add(lookAt.multiply(dist));
    }

    public void strafe(double dist) {
        position = position.add(getRight().multiply(dist));
    }
}

