package wasd;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

public class Raycaster {
    private World world;
    private Player player;
    private ThreadPool pool;
    private ReentrantLock lock;

    private static final Color DARK  = new Color(0.15f, 0.15f, 0.4f);
    private static final Color LIGHT = new Color(0.12f, 0.12f, 0.4f);

    public Raycaster(World w, Player p, int n) {
        world = w;
        player = p;
        pool = new ThreadPool(n);
        lock = new ReentrantLock();
    }

    public void stop() {
        pool.stop();
    }

    private void drawColumn(int width, int height, Graphics g, int n) {
        // calculate the height of the wall to draw
        double prop = (double) n / (width - 1);
        double deg = (1 - prop - prop) * player.getFieldOfView() / 2;
        Vector2 viewDir = player.getLookAt().rotate(deg);
        Tuple2<Double, Boolean> dist = world.getDistanceToWall(player.getPosition(), viewDir);
        double wallHeight = height / dist.getFirst();

        // center the wall vertically
        int topY = (int) (height - wallHeight) >> 1;
        int botY = (int) (height + wallHeight) >> 1;

        // draw the wall
        g.setColor(dist.getSecond() ? DARK : LIGHT);
        g.drawLine(n, topY, n, botY);
    }

    public BufferedImage render(int width, int height) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = img.getGraphics();

        // initialize the background with black
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, width, height);

        final Condition allColumnsDone = lock.newCondition();
        final AtomicInteger counter = new AtomicInteger(0);
        lock.lock();

        for (int col = 0; col < width; ++col) {
            final int fCol = col;

            pool.schedule(() -> {
                drawColumn(width, height, g, fCol);
                lock.lock();

                if (counter.incrementAndGet() == width) {
                    allColumnsDone.signal();
                }

                lock.unlock();
            });
        }

        allColumnsDone.awaitUninterruptibly();
        lock.unlock();

        return img;
    }
}

