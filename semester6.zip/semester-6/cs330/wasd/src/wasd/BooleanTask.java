package wasd;

@FunctionalInterface
public interface BooleanTask {
    public boolean run();
}

