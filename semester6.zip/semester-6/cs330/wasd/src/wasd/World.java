package wasd;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class World {
    private int width;
    private int height;
    private Vector2 start;
    private Vector2 lookAt;
    private boolean[][] map;

    public World(File file) throws FileNotFoundException {
        Scanner kb = new Scanner(file);

        // parse width and height
        String[] line = kb.nextLine().split(" ");
        width = Integer.parseInt(line[0]);
        height = Integer.parseInt(line[1]);
        map = new boolean[width][height];

        // parse player start position
        line = kb.nextLine().split(" ");
        start = new Vector2(Double.parseDouble(line[0]), Double.parseDouble(line[1]));

        // parse player look at position
        line = kb.nextLine().split(" ");
        lookAt = new Vector2(Double.parseDouble(line[0]), Double.parseDouble(line[1]));

        for (int z = 0; z < height; ++z) {
            line = kb.nextLine().split(" ");

            for (int x = 0; x < width; ++x) {
                map[x][z] = line[x].equals("1");
            }
        }

        kb.close();
    }

    public Vector2 getStart() {
        return start;
    }

    public Vector2 getLookAt() {
        return lookAt;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int get(int x, int z) {
        return map[x][z] ? 1 : 0;
    }

    public boolean isPassage(int x, int z) {
        if (x < 0 || x >= width || z < 0 || z >= height) return false;
        return !map[x][z];
    }

    public boolean isPassage(Vector2 position) {
        return !map[(int) position.getX()][(int) position.getY()];
    }

    public Tuple2<Double, Boolean> getDistanceToWall(Vector2 location, Vector2 normViewDir) {
        double rayPosX = location.getX();
        double rayPosZ = location.getY();
        double rayDirX = normViewDir.getX();
        double rayDirZ = normViewDir.getY();

        int mapX = (int) rayPosX;
        int mapZ = (int) rayPosZ;

        double deltaDistX = Math.sqrt(1 + rayDirZ*rayDirZ / (rayDirX*rayDirX));
        double deltaDistZ = Math.sqrt(1 + rayDirX*rayDirX / (rayDirZ*rayDirZ));

        double sideDistX = deltaDistX * (rayDirX < 0 ? (rayPosX - mapX) : (mapX + 1.0 - rayPosX));
        double sideDistZ = deltaDistZ * (rayDirZ < 0 ? (rayPosZ - mapZ) : (mapZ + 1.0 - rayPosZ));

        int stepX = (rayDirX < 0 ? -1 : 1);
        int stepZ = (rayDirZ < 0 ? -1 : 1);

        boolean hit = false;
        boolean side = false;

        // DDA
        while (!hit) {
            if (sideDistX < sideDistZ) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = false;
            } else {
                sideDistZ += deltaDistZ;
                mapZ += stepZ;
                side = true;
            }

            hit = map[mapX][mapZ];
        }

        double perpWallDist = side ?
                              (mapZ - rayPosZ + (1 - stepZ) / 2) / rayDirZ:
                              (mapX - rayPosX + (1 - stepX) / 2) / rayDirX;

        return new Tuple2<Double, Boolean>(perpWallDist, side);
    }
}

