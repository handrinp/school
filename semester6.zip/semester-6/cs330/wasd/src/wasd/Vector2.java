package wasd;

public class Vector2 {
    private final double x;
    private final double y;

    public Vector2(final double x, final double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double length() {
        return Math.sqrt(x*x + y*y);
    }

    public Vector2 add(Vector2 u) {
        return new Vector2(x + u.x, y + u.y);
    }

    public Vector2 subtract(Vector2 u) {
        return new Vector2(x - u.x, y - u.y);
    }

    public Vector2 multiply(double r) {
        return new Vector2(r*x, r*y);
    }

    public Vector2 divide(double r) {
        return multiply(1/r);
    }

    public Vector2 normalize() {
        return divide(length());
    }

    public Vector2 rotate(double deg) {
        double rad = deg * Math.PI / 180;
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);
        return new Vector2(x*cos - y*sin, x*sin + y*cos);
    }

    @Override
    public String toString() {
        return String.format("%f,%f", x, y);
    }
}

