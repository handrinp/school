package wasd;

public class Tuple2<U, V> {
    private U fst;
    private V snd;

    public Tuple2(U first, V second) {
        fst = first;
        snd = second;
    }

    public U getFirst() {
        return fst;
    }

    public V getSecond() {
        return snd;
    }
}

