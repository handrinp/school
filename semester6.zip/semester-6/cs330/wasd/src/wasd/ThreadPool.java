package wasd;

import java.util.concurrent.LinkedBlockingQueue;

public class ThreadPool {
    private int numThreads;
    private LinkedBlockingQueue<BooleanTask> tasks;
    private Thread[] threads;

    public ThreadPool(int numThreads) {
        tasks = new LinkedBlockingQueue<BooleanTask>();
        threads = new WorkerThread[numThreads];
        this.numThreads = numThreads;

        for (int i = 0; i < numThreads; ++i) {
            threads[i] = new WorkerThread();
            threads[i].start();
        }
    }

    public void stop() {
        boolean swallowed;

        for (int i = 0; i < numThreads; ++i) {
            swallowed = false;

            while (!swallowed) {
                try {
                    tasks.put(() -> {return true;});
                    swallowed = true;
                } catch (InterruptedException e) {
                    // you must take your pills if you want to get better!!!
                }
            }
        }
    }

    public void schedule(Runnable r) {
        boolean inserted = false;

        while (!inserted) {
            try {
                tasks.put(() -> {
                    r.run();
                    return false;
                });

                inserted = true;
            } catch (InterruptedException e) {
                // keep on spinnin'
            }
        }
    }

    private class WorkerThread extends Thread {
        public void run() {
            boolean poisoned = false;
            BooleanTask task;

            while (!poisoned) {
                try {
                    task = tasks.take();
                    poisoned = task.run();
                } catch (InterruptedException e) {
                    // keep on spinnin'
                }
            }
        }
    }
}

