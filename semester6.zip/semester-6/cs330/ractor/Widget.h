#pragma once

#include <string>
#include <sstream>
#include <vector>
#include <functional>
#include <iostream>
#include <ncurses.h>

#include "Rectangle.h"

using namespace std;

class Widget {
    private:
        Rectangle box;
        bool looping;

    public:
        Widget(int left, int right, int top, int bottom);
        virtual ~Widget();
        const int GetLeft();
        const int GetRight();
        const int GetTop();
        const int GetBottom();
        const bool Contains(int x, int y);
        void Resize(int x, int y);
        virtual void Draw();
        virtual void OnMouseClick(int x, int y);
};

