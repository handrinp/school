#pragma once

#include "Widget.h"

class Window : public Widget {
    private:
        vector<Widget*> widgets;
        bool looping;

    public:
        Window();
        ~Window();
        void Add(Widget *widg);
        void Draw();
        void Loop();
        void Stop();
};

