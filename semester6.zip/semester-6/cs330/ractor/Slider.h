#include "Widget.h"

class Slider : public Widget {
    private:
        vector<function<void(int)>> listeners;
        int value;
        int max;

    public:
        Slider(int x, int y, int max, int def);
        const int GetValue();
        const int GetMax();
        void Draw();
        void AddListener(function<void(int)> listener);
        void OnMouseClick(int x, int y);
};

