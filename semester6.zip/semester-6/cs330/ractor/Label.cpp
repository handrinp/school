#include "Label.h"

Label::Label(int x, int y, const string str) : Widget(x, x + str.length() - 1, y, y) {
    text = str;
}

void Label::Draw() {
    mvprintw(Label::GetTop(), Label::GetLeft(), text.c_str());
}

void Label::SetText(const string str) {
    text = str;
    Resize(str.length(), 1);
}

