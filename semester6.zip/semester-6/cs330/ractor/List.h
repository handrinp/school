#include "Widget.h"

class List : public Widget {
    private:
        vector<string> list;
        vector<function<void(int)>> listeners;
        unsigned int index;

    public:
        List(int x, int y, const vector<string> items);
        const int GetSelectedIndex();
        const string GetSelected();
        void Draw();
        void OnMouseClick(int x, int y);
        void AddListener(function<void(int)> listener);
};

