#pragma once

#include "Widget.h"

class Checkbox : public Widget {
    private:
        string text;
        vector<function<void(bool)>> listeners;
        bool checked;

    public:
        Checkbox(int x, int y, const string str);
        void Draw();
        void SetText(const string str);
        void AddListener(function<void(bool)> listener);
        void OnMouseClick(int x, int y);
        bool IsChecked();
        void IsChecked(bool czecht);
};

