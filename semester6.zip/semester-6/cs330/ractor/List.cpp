#include "List.h"

List::List(int x, int y, const vector<string> items) : Widget(x, x, y, y) {
    list = items;
    listeners = {};
    index = -1;
    unsigned int biggestLength = 0;

    for (string str : items) {
        if (str.length() > biggestLength) {
            biggestLength = str.length();
        }

        Resize(biggestLength, list.size());
    }
}

const int List::GetSelectedIndex() {
    return index;
}

const string List::GetSelected() {
    return list[index];
}

void List::Draw() {
    for (unsigned int i = 0; i < List::list.size(); ++i) {
        if (i == index) attron(A_REVERSE);
        mvprintw(i + GetTop(), GetLeft(), list[i].c_str());
        if (i == index) attroff(A_REVERSE);
    }
}

void List::OnMouseClick(int x, int y) {
    index = (List::index == (unsigned int)y) ? -1 : y;

    for (function<void(int)> listener : listeners) {
        listener(List::index);
    }
}

void List::AddListener(function<void(int)> listener) {
    listeners.push_back(listener);
}

