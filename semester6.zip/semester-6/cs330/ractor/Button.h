#pragma once

#include "Widget.h"

class Button : public Widget {
    private:
        string text;
        vector<function<void()>> listeners;

    public:
        Button(int x, int y, const string str);
        void Draw();
        void SetText(const string str);
        void AddListener(function<void()> listener);
        void OnMouseClick(int x, int y);
};

