#include "Checkbox.h"

Checkbox::Checkbox(int x, int y, const string str) : Widget(x, x + str.length() + 3, y, y) {
    listeners = {};
    text = str;
    checked = false;
}

void Checkbox::Draw() {
    stringstream ss;
    ss << "[";
    ss << (checked ? 'x' : ' ');
    ss << "] ";
    ss << text;
    mvprintw(GetTop(), GetLeft(), ss.str().c_str());
}

void Checkbox::SetText(const string str) {
    text = str;
    Resize(str.length() + 3, 1);
}

void Checkbox::AddListener(function<void(bool)> listener) {
    listeners.push_back(listener);
}

void Checkbox::OnMouseClick(int x, int y) {
    checked = !checked;

    for (function<void(bool)> listener : listeners) {
        listener(checked);
    }
}

bool Checkbox::IsChecked() {
    return checked;
}

void Checkbox::IsChecked(bool czecht) {
    checked = czecht;
}

