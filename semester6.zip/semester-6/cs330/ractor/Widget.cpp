#include "Widget.h"

Widget::Widget(int left, int right, int top, int bottom) : box(left, right, top, bottom) {
}

Widget::~Widget() {
}

const int Widget::GetLeft() {
    return box.GetLeft();
}

const int Widget::GetRight() {
    return box.GetRight();
}

const int Widget::GetTop() {
    return box.GetTop();
}

const int Widget::GetBottom() {
    return box.GetBottom();
}

const bool Widget::Contains(int x, int y) {
    return box.Contains(x, y);
}

void Widget::Resize(int x, int y) {
    box.SetRight(box.GetLeft() + x - 1);
    box.SetBottom(box.GetTop() + y - 1);
}

void Widget::Draw() {
}

void Widget::OnMouseClick(int x, int y) {
}

