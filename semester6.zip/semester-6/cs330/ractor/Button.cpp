#include "Button.h"

Button::Button(int x, int y, const string str) : Widget(x, x + str.length() - 1, y, y) {
    listeners = {};
    text = str;
}

void Button::Draw() {
    attron(A_REVERSE);
    mvprintw(GetTop(), GetLeft(), text.c_str());
    attroff(A_REVERSE);
}

void Button::SetText(const string str) {
    text = str;
    Resize(str.length() - 1, 1);
}

void Button::AddListener(function<void()> listener) {
    listeners.push_back(listener);
}

void Button::OnMouseClick(int x, int y) {
    for (function<void()> listener : listeners) {
        listener();
    }
}

