#include "Rectangle.h"

Rectangle::Rectangle(int l, int r, int t, int b) {
    left = l;
    right = r;
    top = t;
    bottom = b;
}

const int Rectangle::GetLeft() {
    return left;
}

const int Rectangle::GetRight() {
    return right;
}

const int Rectangle::GetTop() {
    return top;
}

const int Rectangle::GetBottom() {
    return bottom;
}

void Rectangle::SetLeft(int l) {
    left = l;
}

void Rectangle::SetRight(int r) {
    right = r;
}

void Rectangle::SetTop(int t) {
    top = t;
}

void Rectangle::SetBottom(int b) {
    bottom = b;
}

const int Rectangle::GetWidth() {
    return 1 + right - left;
}

const int Rectangle::GetHeight() {
    return 1 + bottom - top;
}

const bool Rectangle::Contains(int x, int y) {
    return x >= left && x <= right && y >= top && y <= bottom;
}

const bool Rectangle::Intersects(Rectangle r) {
    return !(left > r.GetRight() || right < r.GetLeft() || top > r.GetBottom() || bottom < r.GetTop());
}

