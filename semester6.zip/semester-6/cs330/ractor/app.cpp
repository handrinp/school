#include "Slider.h"
#include "Label.h"
#include "Window.h"

int main(int argc, char *argv[]) {
    // main window for drawing
    Window *win = new Window();

    // initialize graphics
    int catX = 1;
    int catY = 3;
    unsigned int numParts = 14;

    vector<string> catLHS = {
        "             ",
        "             ",
        "             ",
        "             ",
        "  |\\         ",
        " /, ~\\       ",
        "X     `-.....",
        " ~-. ~  ~    ",
        "    \\        ",
        "     \\  /_   ",
        "     | /\\ ~~~",
        "     | | \\   ",
        "     | |\\ \\  ",
        "    (_/ (_/  "
    };

    vector<string> catMids = {
        " ",
        " ",
        " ",
        " ",
        " ",
        " ",
        "-",
        " ",
        " ",
        " ",
        "~",
        " ",
        " ",
        " ",
        " "
    };

    vector<string> catRHS = {
        "         _",
        "        | \\",
        "        | |",
        "        | |",
        "        | |",
        "       / /",
        "-----./ /",
        "        |",
        "   /    |",
        "___\\   /",
        "   \\\\ |",
        "   || |",
        "   || )",
        "  ((_/"
    };

    // initialize widgets
    vector<Label *> labels = {};
    Slider *catLength = new Slider(3, 2, 20, 5);
    Label  *lb        = new  Label(3, 1, "Cat length");

    for (unsigned int i = 0; i < numParts; ++i) {
        stringstream ss;
        ss << catLHS[i];

        for (unsigned int stretch = 0; stretch < 5; ++stretch) {
            ss << catMids[i];
        }

        ss << catRHS[i];
        labels.push_back(new Label(catX, catY + i, ss.str()));
    }

    // add event handlers
    catLength->AddListener([&] (int len) {
        for (unsigned int i = 0; i < numParts; ++i) {
            stringstream ss;
            ss << catLHS[i];

            for (int stretch = 0; stretch < len; ++stretch) {
                ss << catMids[i];
            }

            ss << catRHS[i];
            labels[i]->SetText(ss.str());
        }
    });

    // add the controls to the window
    win->Add(catLength);
    win->Add(lb);

    for (unsigned int i = 0; i < numParts; ++i) {
        win->Add(labels[i]);
    }

    // start the app
    win->Loop();
}

