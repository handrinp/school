#include "Window.h"

Window::Window() : Widget(-1, -1, -1, -1) {
    widgets = {};
    looping = false;
    initscr();
    noecho();
    curs_set(0);
    keypad(stdscr, true);
    mousemask(BUTTON1_CLICKED, NULL);
}

Window::~Window() {
    for (Widget *w : widgets) {
        delete w;
    }
}

void Window::Add(Widget *widg) {
    widgets.push_back(widg);
}

void Window::Draw() {
    clear();

    for (Widget *w : widgets) {
        w->Draw();
    }
}

void Window::Loop() {
    looping = true;
    int input;
    MEVENT event;

    while (looping) {
        Window::Draw();
        input = getch();

        if (input == 'q') {
           Window::Stop();
        } else if (input == KEY_MOUSE && getmouse(&event) == OK && event.bstate & BUTTON1_CLICKED) {
            for (Widget *w : widgets) {
                if (w->Contains(event.x, event.y)) {
                    w->OnMouseClick(event.x - w->GetLeft(), event.y - w->GetTop());
                }
            }
        }

        Window::Draw();
    }

    endwin();
}

void Window::Stop() {
    looping = false;
}

