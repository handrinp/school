#pragma once

#include "Widget.h"

class Label : public Widget {
    private:
        string text;

    public:
        Label(int x, int y, const string str);
        void Draw();
        void SetText(const string str);
};

