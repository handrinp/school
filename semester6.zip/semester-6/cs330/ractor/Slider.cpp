#include "Slider.h"

Slider::Slider(int x, int y, int maxValue, int defaultValue) : Widget(x, x + maxValue, y, y) {
    listeners = {};
    value = defaultValue;
    max = maxValue;
}

const int Slider::GetValue() {
    return value;
}

const int Slider::GetMax() {
    return max;
}

void Slider::Draw() {
    for (int i = 0; i <= GetMax(); ++i) {
        mvprintw(GetTop(), i + GetLeft(),
            i == GetValue() ? "o" : "."
        );
    }
}

void Slider::OnMouseClick(int x, int y) {
    value = x;

    for (function<void(int)> listener : listeners) {
        listener(GetValue());
    }
}

void Slider::AddListener(function<void(int)> listener) {
    listeners.push_back(listener);
}

