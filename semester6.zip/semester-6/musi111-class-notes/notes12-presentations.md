Day 1
=====

Iris
----
- Song: Edelweiss
- Performed by: Rodgers and Oscar Hammerstein II
- From *The Sound of Music*, 1959

Keenan
------
- Song: Cheer Up
- Performed by: Reel Big Fish :)
- Awesome ska song

Brett
-----
- Song: Guten Abend, Gute Nacht
- Performed by: Johannes Brahms
- German lullaby

Lauren
------
- Song: Lord I Lift Your Name on High
- Hand motions made church less boring

Nick (me!)
----------
- Song: Try it, You'll Like it
- Performed by: Dick Rodgers

Alvin
-----
- Song: Words
- Performed by: Bee Gees

Jun
---
- Song: Shi shang zhi you ma ma hao
- Translation: Mother is the best in the world

Mark
----
- Song: Sleigh Ride
- Performed by: Ronettes

Hayley
------
- Song: Unforgettable Tonight
- Performed by: Li Guyi
- Performed at the end of the Spring Festival

Ally
----
- Song: St. Judy's Comet
- Performed by: Paul Simon

Alissa N
--------
- Song: Silent Night
- Performed by: Kelly Clarkson

Jamie
-----
- Song: Rebetiko Dance
- Performed by: Paleochora
- Greek refugees coming back from Turkish empire

Jacob
-----
- Song: Crash Into Me
- Performed by: Dave Matthews Band

Heather
-------
- Song: Great day to be alive
- Performed by: Travis Tritt

Wyatt
-----
- Song: I Walk the Line
- Performed by: Johnny Cash

Carter
------
- Song: The Dance
- Performed by: Garth Brooks

Bennett
-------
- Song: This Land is Your Land
- Performed by: Woodie Guthrie

Reasons why music is special to people
--------------------------------------
- Nostalgic memory response to music
- Memory of family members
- Specific life events
- Celebrations/festivals
- Bring comfort/emotional response

Day 2
=====

Sisi
----
- Song: Beside the Water
- Chinese traditional poem about a sad love story

Taylor G
--------
- Song: Amazing Grace (My Chains are Gone)
- Performed by: Chris Tomlin
- Different that original Amazing Grace song, variation is in chorus

Taylor P
--------
- Song: Come Sail Away
- Performed by: Styx

Jack L
------
- Song: My Choice
- Performed by: Jimmy Sturr

Rachel
------
- Song: This Little Light of Mine
- Arranged by: Val Hicks

Jake
----
- Song: Searching for a Rainbow
- Arranged by: Marshall Tucker Band

Emily D
-------
- Song: Johnny Appleseed Prayer
- Performed by: Vella Rae
- Adorable kid singing the song!

Kristen
-------
- Song: Now The Light Has Gone Away
- Performed by: Koine
- Song 2: Jack-o'-Lantern

Ryan
----
- Song: Roll out the Barrel
- Performed by: Frankie Yankovic
- Very classic polka song - my grandma suggested this song as well!

Tom
---
- Song: Tears in Heaven
- Performed by: Eric Clapton
- Played at half-brother's funeral :(

Emily W
-------
- Song: White Christmas
- Performed by: Elvis Presley

Junji
-----
- Song: Arirang
- Performed by: IU
- Sing during festival

Yui
---
- Song: Everybody Needs Somebody
- Performed by: Love Psychedelico
- Song was and still is motivation for Yui to study English

Jesse
-----
- Song: Born to be Wild
- Performed by: Steppenwolf
- "Time to clean up" song growing up

Dawson
------
- Song: Party in the USA
- Performed by: Miley Cyrus
- When this song came out, I hated it, but now it's okay

Jeffrey
-------
- Song: Lug Txaj
- Performed by: Chuevang Xiong
- Lug Txaj is not a specific song, but a genre of song
- Separation song about homeland

Jack
----
- Song: Simple Man
- Performed by: Lynyrd Skynyrd
- I prefer the Simple Man cover since it's less twangy, just my taste

Gabrielle
---------
- Song: Scarborough Fair
- Performed by: Simon and Garfunkel
- Almost sounds like middle ages music

Sajad
-----
- Song: Qoulee Ouhibbouka
- Performed by: Kadim Alsaheir
- Not exposed to song by family, but very popular song
- Title translates to "Say I Love You"

Alyssa
-------
- Song: The Laughing Polka (Whoopee)
- Performed by: John Wilfahrt
- This is a laugh riot

Different ways music was used today
-----------------------------------
- As an all around good feeling song
- To bring back memories from childhood
- As an inspiration to learn a language

Day 3
=====

Holly
-----
- Song: Dominic the Donkey
- Performed by: Lou Monte

Arab Detroit Links
------------------
- Musical instruments:
    - Kamaan - looks like a violin
    - durbakk i/ tabla - drum
    - O'od - big guitar drum
    - Qanoon - large harp thing with bendable strings
    - Ney - recorder thing
    - Mughanniyat - vocals
    - Mizmar - double reeded clarinet thing
    - Riqq - tambourine that can be very heavy, requires ring finger strength
    - Tabi Baladi - Large marching drum
    - Zaffah - large stringed instrument
- Cousin with broken leg plays Qanoon
    - He has little finger pick things
    - He plucks some strings, and picks others
- Ney players
    - Lips used to create vibrato
    - Mouth, fingers, and blowing can be used to create vibrato
    - Side of lip raised can cause vibrato
- Last dance
    - Slow steps with leg raising
- Wedding procession
    - Bridge/groom are not the center of attention
    - Instead, a show is being put on for them
- Mawwal
    - Vocals with a lot of tremolo/vibrato
    - Compliments/nice things said about brie/groom, but sung!
- Belly Dance: Haflah
    - Slower dance
    - Less revealing clothes than the stereotype
    - Finger snapping

Irish Links
-----------
- Tap dancing
    - Very skilled and rehearsed
- Irish Washerwoman
    - Dueling fiddles
    - No vocals, except for "ay!"

