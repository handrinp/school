Native American Appropriation
=============================

Appropriation in music
----------------------
- Ghost dances
- Prayer songs

Plastic shamans
---------------
- Not actually affiliated with any cultures/traditions

Ethical issues of plastic shamans
---------------------------------
- Spiritual dangers
    - Traditional elders claim that there is danger in trusting these people
    - Harms reputation of cultures/communities misrepresented
    - Give people false ideas about traditional spirituality and ceremonies

Real shamanic music and healing
-------------------------------
- Claims to treat many conditions

Logo/Mascot controversies
-------------------------
- BuzzFeed video on Native Americans trying on "Indian" costumes
    - Meaning is stripped from the actual clothing
    - Clothing is offensive and stereotyping
    - They feel as though their culture is being mocked
- Victoria Secret fashion show
    - People unaware of the significance or history behind cultural traditions

Frances Densmore
----------------
- Recorded/preserved thousands of songs
- Songs were transcribed through a non-native lens
- The music wasn't re-performed as it was meant to be heard
- Took away from the spiritual power of the songs

Native American oppression
-------------------------
- Sundance ceremony
    - After European colonization of the Americans
    - Illegal in US until late 1978
- Ghost dance
    - Traditional circle dance associated with cross-cultural coopoeration
    - Wounded Knee massacre did not end the Ghost dance religious movement

Stereotypes in movies
---------------------
- Peter Pan - What Makes the Red Man Red
- Pocahontas - pretty much the whole movie


Supplemental notes
==================

White/Plastic Shamans video
---------------------------
- Many fraudulant groups claim to allow you to buy tribe access
    - This is done to ignorant/naiive people unfairly
    - Money is charged for these though it shouldn't
- Selection process for shamans is supernatural, not commercial
    - One can't become a shaman by wanting it... they must be spiritually "chosen"

Instrumental accompaniment
--------------------------
- Some say it detracts from the message
- Some say it helps add to the message
    - Physiological supplement
    - Can be helpful in musical therapy
- Many factors to be considered before adding instruments (cultural, spiritual, ethical)

