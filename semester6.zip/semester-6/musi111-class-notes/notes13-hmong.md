Review for Listening Midterm
----------------------------
- Polka
    - Happy, upbeat
    - oom-pa-pa
- Klezmer
    - Clarinet lead
    - Jewish music - may have Hebrew singing/talking
- Mariachi
    - String instruments
    - Mexican
- Arab Detroit
    - Many percussion instruments
    - Arab music - may have Arabic singing/talking
- Matachines
    - Influenced by European folk (violin)
    - Native American pow-wow style (pounding of drums and jingle dress)

Hmong Music Notes
-----------------
- Suab (god) gave two kinds of music: secular and sacred
- Raj
    - Flute used to speak through
    - Short one: Raj hliav neauj
    - Long one: Raj nplaim
- Qeej
    - Instrument
    - Only to be used for sacred music
    - Kids not allowed to play it
    - Used in Hmong funeral rituals
    - Made of several bamboo pipes connected to a reed
    - Can play two or more notes at once, so it's difficult to understand the words
- Rhymed poetry
    - kwv txhiaj
    - has no written form, and must by learned by ear
    - can be sung at any time, and discuss any topic
- Traditionaly Hmong music is usually performed alone
- Translates text into music
- 7 word tones represented by different suffixes
    - high - b
    - low - s
    - middle
    - rising - v
    - falling - j
    - low breathy - g
    - low abrupty - m

2 Historical lines of music
---------------------------
- Port of New Orleans
    - Modelled after town of Orleans in France
    - Music reflects France
    - Canadian music (Cajun)
    - Spanish influence from the islands, Mexico, Cuba
- New England psalmody
    - Psalmody: taking psalms from holy scripture and putting them to music
    - Women not allowed out of the house
    - Singing schools were important to the women

