Congo Square
============

Cakewalk - Ragtime/Comedy
-------------------------
- Dance and clothing are interesting
- Period clothing, but West African-influenced dance
- Knees shaking a lot, very energetic dance style

Banjo - Ragtime
---------------
- Banjo plays picks/plucks instead of strums
- Banjo playing imitates ragtime piano

Scott Joplin - Maple Leaf Rag
-----------------------------
- Bouncy piano playing

The Entertainer
----------------------------------
- Difficult staccato style of playing
    - 4 year old played it - Cute!!!
    - People played it on large

Congo Square Fest
-----------------
- Many colors in the dresses
- Head coverings also colorful
- Drums repetitive

Ring Shout
----------
- Dance/song in a circle
    - Symbolizes connection bewteen past/present/future

Hush Harbors
------------
- Places at night where slaves could practice their religion freely
- Yelled into "hush hats" during worships to remain quiet

Field Hollers and Work Songs
----------------------------
- Call and response style was used sometimes
- Video narrated in French lol

Chain Gang song
---------------
- Use work tools to keep rhythm/beat
- More call and response

Day 2
=====

Gullah People
-------------
- Gullah comes from West Africa most likely
    - From te word "Gola" (a tribe) or possibly Angola
- Gullah were rice growers
- Transportation was done largely by boats
- Music has a distinctive beat

Gullah Shout
------------
- Politically incorrect images
    - Golliwogs: creepy black faced dolls

Golliwog's Cakewalk
-------------------
- No vocals - all piano
- Tons of historical references!
    - Mocks Wagner music with music quote (Hitler utilized)
- Paralleling what's happening in New Orleans with what happened during the Holocaust

La Bamboula - danse des Negres, Op. 2
-------------------------------------
- Played by L. M. Gottschalk
- Super catchy piano piece
    - Many different play styles throughout the song

The Banjo - Gottschalk
----------------------
- Song imitates the sound of a banjo
- Quotation from Steven Foster - "Camptown Races"
- "Sounds like 80 pianists at 40 pianos"
    - Masterpiece

Hey Pockey Way
--------------
- Mardi Gras Indian chant
- Sounds almost bluesy
    - Electric guitar is funky

Clave
-----
- Really cool drum beats performed
- People going "la la la la" to the beat of various percussion instruments

Dr. John - Iko Iko
------------------
- "Spy boy" goes to find out what the other gangs are trying to do
    - "gang" not the same as today
    - just a group or people, all done in fun


Day 3
=====
- Various rhythmic instruments are used

Kalimba video
-------------
- Playing was used to unwind after a long day
- The tiny shaker instrument was louder than all the kalimbas

Big Kalimba
-----------
- Played "Puff, the Magic Dragon"

Quills
------
- Henry Thomas - Bull doze Blues 1928
- Sounds like a flute, but very high pitched

Hambone
-------
- Clapping, slapping, and patting
- Very rhythmic
- Fun and energetic

Buckwheat Zydeco 
----------------
- Jazz and Heritage Festival
- Many horn instruments, drums, bass, and the washboard thing
- Callbacks with the crowd

Ashkenaz
--------
- Accordian and guitar also played


Day 4
=====

Guaguano video
--------------
- Layer of singers, and layer of different drum beats

Dance steps
-----------
- Moving hips and bending your knee
- Easy Latin dance: merengue

Haitian merengue
----------------
- Couples dancing
- Influenced compas music
- Need to hear to music to get used to the subdivisions

Haitian petwo
-------------
- Precursor to voudou-type things
- Very difficult to count/play

Cuban rumba
-----------
- Handkercheif used as a prop
    - Also used as protection for kids
    - Go towards and then come away from them
- Bellies/thighs touch
- Circling hip movements

Northeastern Brazilian Baiao
----------------------------
- Sounds like polka
- Mandolin, string bass, accordian

Baiao da Pifa
-------------
- Harmonica piece
- Does call and response by himself
- Very energetic performance
- Electric guitar has basic sound

Baiao mix - accordian, guitar, flute
------------------------------------
- Accordian player has zany dress and 6-pointed stars
- Baby vihuela played


Day 5
=====

Bamboula drumming
-----------------
- Bamboula beat sounds just like the word
    - "Bam-bou-la"

Gris-Gris - Dr. John - VooDou medicine - Dr. John - The Night Tripper
---------------------------------------------------------------------
- Dr. John - Gris Gris Gumbo Ya Ya
- Is this made for commercial reasons or is it authentic?
    - It could be a little bit of both
- Notes
    - "I got a remedy to cure you"
    - Backup singers
    - "Try my universal rub"
- "Dr. John" persona is a gimmick
    - He even sold "gris-gris" amulets for voodoo healing

Jazz Funeral - Hall Jazz Band
-----------------------------
- Happy and upbeat music
- Parade "Saints Go Marching"
- Parasols/umbrellas
- Colors yellow/black used often (like fleur-de-lis)


Day 6
=====

Food
----
- Dr. Lee Anna Rasar gave us food :)

The Charleston
--------------
- The original dance
- The dance is recognizable
- Some dance movements are imitated from other dances
- Many other dances imitate the Charleston
    - Similar arm movements
    - Similar kicking

Dancing on casket
-----------------
- Most people find dancing on the casket weird/disrespectful

