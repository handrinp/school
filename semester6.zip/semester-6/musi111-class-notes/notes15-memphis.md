Memphis Music from the perspective of an old person
===================================================

Blue Jay Singers
----------------
- "Well, well" expression
- Quartet with >4 people, but only 4 parts

Selah Jubilee Singers - I'm So Glad
-----------------------------------
- "Hot Gospel"
    * Not on my watch!
    * That's an inappropriate adjective if I've ever seen one

Spirit of Memphis - He Never Left Me Alone
------------------------------------------
- Call and response
- A capella bass

Dixie Hummingbirds
------------------
- Guitar solo
- Vocal effect added in with guitar: falsetto
- Simple dancing: finger snapping
    * Not appropriate - how is this a church service?

Dollar and the Devil
--------------------
- Minimal accompaniment
- Syncopated clapping from audience
    * This was a performance
    * Jesus should be getting the praise, not the band

Swing Low Sweet Chariot
-----------------------
- Harmonies
- Augmentation
    * I appreciate the musical style, but not its use in a service
- Piano version and train noises
    * Why add those unnecessary sounds?

Hush
----
- Most songs about heaven/death
- Thanks audience for applause at the end
- String bass
    * Lounge instrument - doesn't belong in a church

Golden Gate Quartet
-------------------
- "Entertaining you"
    * That's the last straw D:

Roll, Jordan
------------
- Stomp clap is a more traditional style found in church pieces
    * This is okay

"Hard" style
------------
- "Getting on the train"
- Travelling shoes

K4 Presentation
===============
- Song: I'm a Soldier
- Performed by: The Soul Stirrers
- Popular among blue-collar African American workers
- Been popular for nearly 100 years
- Performers wear the same clothes as the churchgoers
    - Establishes themselves as part of the group
- "Hard" quartet with alternating lead singers
- "Jubilee" style with focus on bass and bible verses

