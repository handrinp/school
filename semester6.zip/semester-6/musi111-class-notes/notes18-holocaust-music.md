Music of the Holocaust
======================

Richard Wagner
--------------
- Extremely anti-semitic
- Referred to jews as the "plastic demon of the decline of mankind"
- Good composer though

Ride of the Valkyries
---------------------
- One of Richard Wagner's most popular songs
- Played at the concentration camps whenever Nazi Germany had a war victory

Ring Cycle
----------
- Very long anti-semitic opera epic
- Ride of the Valkyries was played there

Horst-Wessel-Lied
-----------------
- Nazi marching song

Klezmer music
-------------
- Originated from Ashkenazi Jews
- Little was written down/recorded
- Typically played at celebrations, especially weddings
- Music saw a massive revival in the 1970s

Jewish use of Music during the holocaust
----------------------------------------
- Yiddish song 'Es Brent'
- Translates to "It burns"
- Music used during Holocaust as a symbol of hope of freedom to come

We went outside and had a dance activity :)
-------------------------------------------

