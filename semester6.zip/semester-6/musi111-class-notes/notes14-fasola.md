Fasola
======
- Sometimes begins with Fa-So-La, then ends with lyrics
- Uses shapes instead of just circles to represent notes
- Created before American independence
- Lining out is used
    - Call and response manner
    - Because of high illiteracy rate
- William Little and William Smith used shapes to introduce Fasola
- White spiritual music to get spiritual involvement
- Not really bands that perform it, just 

