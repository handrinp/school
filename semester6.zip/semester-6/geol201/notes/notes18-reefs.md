Reefs
=====

Permian Reef Complex
--------------------
- Guadalupe Mountains NP

Today - Chihuahuan Desert
-------------------------
- Mexico through New Mexico/Texas
- Desert environment

Permian - Carbonate Environment
-------------------------------
- A reef is a wave-resistant structure built of plant and animal skeletons
- Carbonate rocks make up the reef
    - Calcite (CaCO3)
    - Dolomite (CaMg(CO3)2)

Permian Basin
-------------
- Fossilized reefs
- Formed along the Delaware Basin

Coral Reef Video
----------------
- Animals form reefs (mostly corals)

Coral
-----
- Stony Corals are the dominate reef builder
- Polyps (living portion of coral) extract Ca from seawater
    - They combine the Ca with C02 to construct limestone skeletons that form the reef
- Reefs grow between 1 and 16 ft every thousand years

Reef Facts
----------
- Coral reefs are home to 25% of all marine life
- 35 million acres of coral reefs have disappeared in the last few decades
    - If this trend continues, 70% of the world reefs will be gone by 2060
    - Major threats include sedimentation, contaminated run-off, over-collection, and global climate change

Artificial Reefs
----------------
- There are >1,800 artificial reefs in State and Federal waters in Florida
- Florida spends &gt;$600,000 annually for rehabilitation
    - Money spent towards resulting $2.8 billion industry

