Caves
=====

Groundwater System
------------------
- Very important resource (think wells)

Caves Overview
--------------
- Caves are a result of dissolution of carbonate rocks at/near the groundwater table
- Cave shape often determined

Karst Topography
----------------
- Style of landforms developed during weathering and erosion of carbonate and evaporite rocks
- Indicator of a nearby cave
- Little sinkholes and stuffs

Speleothems
-----------
- Minerals deposited in caves
- Named based on shape and place of formation
- Stalactites, stalagmites are examples of these

