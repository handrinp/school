Mt St Helens
============


1980 Eruption of Mt St Helens
-----------------------------

- Big chunk of land slid off the mountain
- It had some pyroclastic flow


Lava Domes
----------

- Lava domes may form before/after eruption
- Their collapse often triggers pyroclastic flows

