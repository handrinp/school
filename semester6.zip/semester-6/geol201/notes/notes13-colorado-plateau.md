The Colorado Plateau
====================
- Lots of rivers
- Exposes the most complete geologic history of N. America
- 80% of it is public land

Navajo
------
- Small bands of nomadic hunters and gatherers
- Originated in western Canada
- adopted farming, domestic animals, and pottery making

Water Quality
-------------

