Crater Lake & Mt Rainier
========================


Crater Lake
-----------

- Should be called Caldera lake (it's actually a caldera)
- Makalaks believed that it was so holy that looking at it could kill you
- Formed from volcano's cataclysmic eruption
- Top of volcano collapsed into hole
- Water settled into it, but no water currently flows in/out
- There are 3 dead bodies and a helicopter in the bottom of it


Mt Rainier
----------

- One of the first national parks (1899)
- Around 2 million annual visitors
- Active volcano
- Close to population centers
- Most dangerous volcano in the Cascades
- Lahars (massive mud flows) happen here and they are devastating

