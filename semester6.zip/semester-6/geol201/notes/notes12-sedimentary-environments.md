Sedimentary Environments
========================

Weathering
----------
- Process where rock is broken down at or near the surface
- One of the products from this process is sediment

Mechanical/Physical Weathering
------------------------------
- Rock physically broken into smaller pieces
- Frost wedging: ice expand and forces rock apart
- Organic activity: roots may enlarge cracks in the rocks

Chemical Weathering
-------------------
- Minerals are changed into more stable components
- Due to interaction with water rich in carbonic acid
- H2O + CO2 -> H2CO3
- Leaching:
    - Removal of soluble components with water
    - Changes the rock composition and the water composition
    - Just like making coffee from coffee grounds
    - Leaves behind the spent solid, can't be reused
- Dissolution:
    - Complete dissolving of minerals
    - Carbonate minerals found in chemical sedimentary rocks dissolve completely
    - Limestone is a carbonate - almost every cave is the result of limestone dissolution
- Oxidation:
    - Chemical combination of an element with oxygen
    - Some rocks rust, just like iron
    - Sediments deposited in the presence of air

Soil from Weathering
--------------------
- Eventually, rocks weather into soil
- Soil is 45% weathered rock, 5% organic, and 50% airspace

Main Controls on the Rate of Weathering
---------------------------------------
- Climate: temperature and rainfall
- Parent material: mineral solubility and rock structure

Erosion
-------
- The incorporation of transportation of sediment by a mobile agent
- Water, wind, and ice

Rounding and Sorting
--------------------
- Rounding indicates how far the material was transported
- Sorting often indicates the mechanism of transport

Clastic Sedimentary Rocks
-------------------------
- Conglomerate: coarse grained
- Sandstone: medium grained
- Shale: fine grained

