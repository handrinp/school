Yellowstone National Park
=========================

Yellowstone
-----------
- Located in Wyoming, and is super duper huge.
- Established March 1, 1872
- The first National Park
- Yellowstone averages 3 million visitors/year

Tourism at Yellowstone
----------------------
- 1870: The Hayden Party
- 1886: The Mammoth Hotel
    - 414ft long hotel that lost money and only existed for a few years
- 1915: First automobile enters Yellowstone

The Bison Issue
---------------
- Some of the Bison at Yellowstone carry the brucellosis virus
- This virus causes domestic cattle to abort their calves
- Current policy is that all bison who leave the park are killed
    - Bison like to leave when it gets snowy
    - Controversy/protests about whether Bison should be killed
    - Winter of '97/'98: ~50% of bison wandered out and were killed

The Snowmobile Issue
--------------------
- ~95% of Yellowstone is affected by noise/air pollution caused by snowmobiles
- 2009: YNP revises how many daily snowmobiles are allowed
    - 318 snowmobiles/day
    - 78 coaches/day

The Wolf Issue
--------------
- Overpopulation of elk has been a problem for years
- In 1995, wolves were reintroduced to Yellowstone after a 60 year absence

Nez Perce Trail
---------------
- 1877: US army pursued approximately 800 Nez Perce across the Pacific Northwest
- They surrendered 40 miles from the Canadian border on October 5th

Continental Hotspots
--------------------
- Hotspots don't move - the plates above them move!!
- Complex and produce bimodal volcanism
    - Both mafic and felsic volcanism (but not intermediate)

Caldera Formation
-----------------
- Rising magma bulges at surface
- Cracks form and propagate down, intersecting magma chamber
- This causes an eruption
- Overlying rock collapses, forming the caldera

Yellowstone Caldera
-------------------
- 40 miles across, compared to Crater Lake which is only 5 miles across
- Caldera largely filled in with younger lava flows

Monitoring Yellowstone
----------------------
- Two areas called "resurgent domes"
    - Uplift and deflate
    - Cause a bunch of earthquakes
- The question is not whether YS will erupt again, but when?
- 3 indicators for imminent volcanic activity
    1. increased earthquakes in one area
    2. increase ground deformation of feet or yards in an area
    3. changes in thermal activity
        - Not used at most places
- These happen all the time at Yellowstone, so it's inconclusive

Hydrothermal Alteration
-----------------------
- Rocks chemically changed and often weakened through interaction with hot water
- Silica Sinter and Travertine are examples

Geothermal Features
-------------------
- Hot springs
    - Most common geothermal feature at YS
    - "Morning Glory Hot Spring"
    - Color differences due to microbes that live at different temps
- Geysers
    - Hot steam gases build up pressure below the surface
    - Require storage chambers
    - Often have a cone around opening made of sinter
- Mud pots
    - Hot acidic magma formed where rock is alter to clay and water flow is low

