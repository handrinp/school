Hawaii Volcanoes
================


Hawaii volcanoes national park
------------------------------

- Middle of pacific plate
- 8 large islands, hundreds of smaller ones
- Fumaroles: vents where volcanic gasses escape
    - VOG - volcanic smog
- Hawaiian islands are gravitationally unstable - in danger of collapsing
- Cinder cones - small, steep sided volcanoes built of mafic ash, scoria, and lava


Volcanoes of the Cascade range
------------------------------

- Continental volcanic arc
    - Chain of active stratovolcanoes formed on the edge of the continent
- Stratovolcanoes erupt every few hundred years
- Shield volcanoes erupt every 7 years, on average

