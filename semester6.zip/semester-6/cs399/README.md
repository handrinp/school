CS399
=====
- Here is our work for the independent study directed by [Dr. Jack Tan](http://www.cs.uwec.edu/~tan/).

Inspiration
-----------
- We are inspired!

Milestones
----------
- We have milestones!

Usage
-----
- Before building or running the project, navigate to the top level directory (CS399)
- To build the project, use the command `mvn`
- To run the project, use the command `java -jar target/cs399-aes.jar`
    - After doing this once, you can just use `!java` as a shorthand for the  above

