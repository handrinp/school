package edu.uwec.crypto;

import static edu.uwec.crypto.utils.SubBytes.subBytes;
import static edu.uwec.crypto.utils.ShiftRows.shiftRows;
import static edu.uwec.crypto.utils.MixColumns.mixColumns;
import static edu.uwec.crypto.utils.AddRoundKey.addRoundKey;

public class AES {
    private static final int ROUNDS = 8;

    public static byte[][] chunk(byte[] plaintext) {
        int nChunks = plaintext.length / 16;
        int extra = plaintext.length % 16;
        byte[][] chunks = new byte[nChunks + (extra > 0 ? 1 : 0)][16];

        for (int i = 0; i < nChunks; ++i) {
            for (int j = 0; j < 16; ++j) {
                chunks[i][j] = plaintext[16*i + j];
            }
        }

        if (extra > 0) {
            for (int i = 0; i < extra; ++i) {
                chunks[nChunks + 1][i] = plaintext[16*(nChunks + 1) + i];
            }

            for (int i = extra; extra < 16; ++i) {
                chunks[nChunks + 1][i] = 0;
            }
        }

        return chunks;
    }

    // AES pseudocode
    // Cipher(byte in[16], byte out[16], key_array round_key[Nr+1])
    // begin
    //     byte state[16];
    //     state = in;
    //     AddRoundKey(state, round_key[0]);
    //     for  i = 1  to  Nr-1  stepsize 1 do
    //         SubBytes(state);
    //         ShiftRows(state);
    //         MixColumns(state);
    //         AddRoundKey(state, round_key[i]);
    //     end for
    //     SubBytes(state);
    //     ShiftRows(state);
    //     AddRoundKey(state, round_key[Nr]);
    // end
    public static byte[] encode128bits(byte[] in, byte[] keyArray, byte[] roundKey) {
        byte[] state = new byte[16];

        // copy the input to the state array so we don't modify the original
        for (int i = 0; i < 16; ++i) {
            state[i] = in[i];
        }

        // AES
        addRoundKey(state, roundKey[0]);

        for (int i = 0; i < ROUNDS - 1; ++i) {
            subBytes(state);
            shiftRows(state);
            mixColumns(state);
            addRoundKey(state, roundKey[i]);
        }

        subBytes(state);
        shiftRows(state);
        addRoundKey(state, roundKey[ROUNDS - 1]);

        return state;
    }
}

