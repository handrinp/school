package edu.uwec.crypto.utils;

public class SubBytes {
    public static void subBytes(byte[] state) {
    }
}

