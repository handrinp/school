package edu.uwec.crypto.utils;

public class ShiftRows {
    public static void shiftRows(byte[] state) {
    }
}

