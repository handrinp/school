package edu.uwec.crypto.utils;

public class MixColumns {
    public static void mixColumns(byte[] state) {
    }
}

