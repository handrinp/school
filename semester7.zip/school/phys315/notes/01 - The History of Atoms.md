Greeks
======
- Around 500 B.C.
- A-TOM = "not" "cut" = indivisible unit
- All matter is made of particles too small to be seen
- "Can you continually divide/halve?"
- No, not without nuclear fission
- Atoms and Void - Materialism

Alchemy
=======
- Predates chemistry
- Some materials cannot be changed by chemical processes - Elements
- Elements are the same all around the world

John Dalton
===========
- Atoms neither created nor destroyed
- Atoms act distinctly and consistently
- Atoms combine in natural numbers
- Element - cannot be separated by chemical or physical means (not including nuclear reactions)
- Law of conservation of mass - duh
- Law of definite proportions - pure compounds always contain the same elements in the same proportion by mass

Periodic Table
==============
- Mendeleev organized the table at first by making playing cards and trying to "play solitaire"
- Prediction was made about #33 (As), and when it was discovered, the prediction was more accurate
- Still didn't even know about protons, but still numbered correctly

Atomic Spectroscopy
===================
- 19th century science
- **each element produces a unique set of light wavelengths**, under certain stimuli
- "flame spectrum" used to make different fireworks colors
- Lightbulb - continuous spectrum
- Hot gas - emission line spectrum
- Cold gas - absorption line spectrum

Brownian Motion
===============
- Random motion observed in small particles (but bigger than atoms, like pollen)
- This motion caused by a bunch of tiny atoms hitting the pollen

