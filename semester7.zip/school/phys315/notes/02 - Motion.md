Aristotle
=========
- All matter is made of earth, air, wind, and fire
- Air and fire try to rise up as far as they can get
- Earth and water try to fall down as far as they can get
- Natural motions are **always** up and down, with above rules
- Violent motions require outside force, usually side to side

Galileo
=======
- There is friction that slows things down
- Without friction, you could roll a ball forever (violating Aristotle's idea)
- **The law of inertia**: A body that is subject to no external influences will stay in motion...

Current Understanding
=====================
- Speed is how fast you're going
- Velocity is speed in a direction
- Any change in velocity is acceleration
    - This includes turning

Third Law Pairs
===============
- Due to the third law, every action has an equal an opposite reaction

Physics Yo
==========
- Fondue notation: F<sub>on,due</sub>
    - F = force
    - on = exterted on ...
    - due = due to ...
- F<sub>x,y</sub> = F<sub>y,x</sub>, for all objects x,y

