Homework B
==========
- Nick Handrick
- Due: 2017-09-22

Chapter 4
---------
- RQ: 3, 7, 10, 12, 16, 18
- CE: 5, 8, 12, 15, 17, 18, 23, 27, 32, 34, 35, 36, 43, 44, 48, 49, 50

Solutions
=========

Chapter 4
---------
**Ch4RQ3**)
1. A car accelerating straight
2. A person falling to the earth
3. A car turning
4. A ball rolling to a stop
5. A stretched spring
6. The force bonding protons and neutrons together

**Ch4RQ7**)
An object with more inertia would be harder to accelerate/decelerate.

**Ch4RQ10**)
No - an object in freefall can be moving in any direction, but acceleration downwards.
Yes to the second part.

**Ch4RQ12**)
Mass is independent on gravity.

**Ch4RQ16**)
The largest force is the upward propulsion, the normal force on the exhaust.
The net force is upward facing.

**Ch4RQ18**)
Run two trucks into eachother and observe death.
Swing a rock around on a string and observe it pulling you.
Punch a wall really hard and observe the pain.
Shoot a gun and observe the recoil.

**Ch4CE5**)
Right before you hit the book, the book is at rest.
While the hammer's hitting the book, the force accelerates the book sideways, giving it a velocity.
While there's velocity, friction decelerates the book until it comes to a stop.
Likewise, the hammer also experiences a normal force from the book, but not as hard so it doesn't move as much.

**Ch4CE8**)
There can be forces acting on it, but they are all balancing each other out.
There's no net force on it.

**Ch4CE12**)
The accelerating has a greater net force, because the other car is moving at a steady velocity (equilibrium).

**Ch4CE15**)
The acceleration will be 20 m/s<sup>2</sup>.
After touching the rock, it will no longer be accelerating, but it will continue moving at a constant velocity since
there is no friction.

**Ch4CE17**)
The force of air resistance must be 600N.

**Ch4CE18**)
Ned would continue to accelerate downward at 10m/s<sup>2</sup>.

**Ch4CE23**)
1N of gold on the moon requires more mass than 1N of gold on the Earth, so I'd prefer the moon's gold.

**Ch4CE27**)
Your hand in the first case, and the apple in the second.
Equilibrium.
Equilibrium.

**Ch4CE32**)
True, because of Newton's Third Law.

**Ch4CE34**)
Yes, a normal force.
Yes, a normal force.
The forces are equal, again due to our boy Newton.

**Ch4CE35**)
The forces are the same.
Again, the same.
The care experiences a larger acceleration.

**Ch4CE36**)
Due to the third law, the bullet also exerts a force on the gun.

**Ch4CE43**)
The book and your hand both exert equal and opposite normal forces on each other.
Yes, they are a third law pair.

**Ch4CE44**)
The gravitational force and the normal force.
The normal force is greater.

**Ch4CE48**)
Friction exists for cars on the road.

**Ch4CE49**)
The net force is backwards while braking.
When you let your car coast, the net force is also backwards due to friction, but less than while braking.

**Ch4CE50**)
The hard tires compress less, so the force is more easily transferred to the ground to create a frictional force.

