Homework E
==========
- Nick Handrick
- Due: 2017-11-03

Chapter 11
----------
- RQ: 8, 11, 13, 15, 19, 26, 30
- CE: 3, 4, 7, 12, 13, 14, 16, 19, 21, 24, 25, 28, 31, 35, 38, 40, 42, 43

Chapter 12
----------
- RQ: 12, 13, 21, 22
- CE: 3, 4, 5, 9, 16, 17, 19, 26, 28, 29, 35

Solutions
=========

Chapter 11
----------
**Ch11RQ8**) The cosmic microwave background and the relative distances of galaxies both suggest that the universe
started in a big bang.

**Ch11RQ11**) Hg and Au were not, while He and Li were.

**Ch11RQ13**) We can tell if space is curved by shining parallel lasers long distances and seeing if they
converge/diverge/stay parallel.

**Ch11RQ15**) The big bang made no noise, unlike an explosion!

**Ch11RQ19**) The CMB is the universe's baby picture so to speak.

**Ch11RQ26**) The universe's expansion is speeding up.

**Ch11RQ30**) Why the universe's expansion is speeding up instead of slowing down/staying constant.

**Ch11CE3**) Unlike the special theory of relativity, the general theory of relativity works with accelerations, not
just constant velocity frames of reference.

**Ch11CE4**) Artificial gravity can be installed by spinning a large disk, thus creating centripetal acceleration which
would feel like gravitational acceleration if it was the same rate.

**Ch11CE7**) Velocities and accelerations performed both with real gravity, and in an accelerating reference frame will
both be equivalent.

**Ch11CE12**) The oxygen nuclei didn't, but the subatomic particles did.

**Ch11CE13**) The big bang itself was a macroscopic and historical event that cosmologists are interested in, but also
it dealt with the rapid quantum physical partical reactions that occurred at a subatomic level.

**Ch11CE14**) During the start of the big bang, the universe was still to small, and therefore hot and unstable for
larger nuclei, and thus other elements to form. The universe had to expand and therefore cool off before this could
happen.

**Ch11CE16**) No - the big bang happened everywhere. The space it occupied just expanded.

**Ch11CE19**) No :)

**Ch11CE21**) Technically, no. There is no "edge" of the universe really.

**Ch11CE24**) 180, because the universe is verifiably flat.

**Ch11CE25**) No - photons, and therefore light, didn't exist 300,000 years after the big bang.

**Ch11CE28**) The stars on the outsides of the rings of galaxies revolve around the center of the galaxies way faster
than we expected, implying they have some hidden energy that we call "dark energy". Also, the universe's rate of
expansion is increasing, which would also imply some hidden energy.

**Ch11CE31**) I kind of answered that in Ch11CE28 right above this :)

**Ch11CE35**) Cosmologists expected that the expansion of the universe would be slowing down.

**Ch11CE38**) Ok, Ch11CE28 also answered this one.

**Ch11CE40**) wat

**Ch11CE42**) Chaos theory describes how small changes in the initial conditions of something can affect its long term
behavior. The initial conditions of the universe are no exception.

**Ch11CE43**) The energy is zero, because otherwise the star would be collapsing or expanding.

Chapter 12
----------
**Ch12RQ12**) There's more than one possible path for the light, hence the uncertainty

**Ch12RQ13**) The fields change immediately

**Ch12RQ21**) The double slit experiment

**Ch12RQ22**) Quantized means that there is a minimum amount of matter, and that all measurements of matter come in
discrete, integer multiples of this minimum amount.

**Ch12CE3**) Photons experimentally are the smallest amount of light that exists, and all light comes in integer
multiples of photons.

**Ch12CE4**) Digital refers to the discrete integer multiple part, as opposed to a continuous (real numbery) spectrum

**Ch12CE5**) The EM field collapses into a single state, since its position was measured

**Ch12CE9**) No - EM waves are going through the slits through the field

**Ch12CE16**) Matter waves, through the matter field

**Ch12CE17**) Proton has a shorter wavelength

**Ch12CE19**) We will see an interference pattern on the screen, but it will take much longer to look like one

**Ch12CE26**) Very short

**Ch12CE28**) It would have a larger wavelength

**Ch12CE29**) No. Quantum uncertainty happens at the quantum level - literally on subatomic particles. The result of a
coin flip is macroscopic relative to the quantum level.

**Ch12CE35**) In Newtonian physics, position and momentum can be perfectly measured - no uncertainty. Also in Newtonian
physics, gravity formally exists hahaha

