Homework A
==========
- Nick Handrick
- Due: 2017-09-15

Chapter 2
---------
- RQ: 1, 2, 5, 9, 13, 16
- CE: 2, 5, 11, 16, 22, 39, 40

Chapter 3
---------
- RQ: 1, 2, 9, 13
- CE: 1, 2, 5, 7, 8, 9, 11, 12, 17, 20, 21, 22, 26, 27, 30, 31, 32, 33, 35

Solutions
=========

Chapter 2 RQ
------------
**1**)
Things have smells, suggesting that microscopic amounts of materials float around in the air - atoms!

**2**)
Brownian motion is an example of light-based microscope evidence of atoms.

**5**) 
A wavelength of light is WAY bigger than an atom.

**9**)
The periodic table is arranged left to right top to bottom based on the number of protons each element has.
It is also organized into groups of similar properties and number of electrons in the outer shell.

**13**)
Gases are the easiest to compress because there is a lot of empty space within them.

**16**)
According to atomic materialism, love, deliciousness, and swag are not real.

Chapter 2 CE
------------

**2**)
Carbon monoxide 3:4, carbon dioxide 3:8.

**5**)
H<sub>2</sub>SO<sub>4</sub> has 7 atoms per molecule.

**11**)
I would expect F, Br, and I to bond with H like Cl does.

**16**)
Approximately 3 tons of CO<sub>2</sub> gas.

**22**)
The air pressure will increase.
This is because the air molecules have more energy and are flying around with more gusto.

**39**)
Approximately 50,000 to 500,000 atoms across.

**40**)
The dust cube would contain between 5.0&#215;10<sup>12</sup> and 5.0&#215;10<sup>15</sup> atoms.

Chapter 3 RQ
------------

**1**)
Solid objects falling, water falling or running downhill, air rising, and flames leaping upward.

**2**)
Pulling a cart along a road and throwing a stone.

**9**)
About 100km.

**13**)
Per means division, or "in each".

Chapter 3 CE
------------

**1**)
Aristotle would interpret this as the stopping of the violent initial motion.
Galileo would interpret this as friction, due to the roughness of the ball and the surface.

**2**)
Inertia keeps meteoroids moving in space.

**5**)
No.

**7**)
The standing passengers have inertia from when the bus was still moving.

**8**)
No - because turning the car implies acceleration.

**9**)
No, Mary's velocity/speed must have been higher to pass him.
Due to the intermediate value theorem, she must have had the same velocity as him at some point, but not while passing
him.

**11**)
Both balls have the same acceleration (0).
The second ball has a higher speed and velocity.
The second ball passes the first ball after 2 time units.

**12**)
Your speed would be 90 km/hr, and your velocity would be 90 km/hr in the west direction.

**17**)
Motion sickness is due to acceleration/jerk, not velocity.
Constant velocity (and often, constant acceleration) does not make people sick.

**20**)
The first ball is accelerating at 1 distance unit/time unit, and the second ball has a constant 4 distance units/time
unit velocity.
They have the same speed between 3 and 4 time units.

**21**)
Yes, no, yes, yes, no.

**22**)
Yes and yes.

**26**)
Distance changes quadratically, while speed and velocity change linearly.

**27**)
Her acceleration is 0.3 m/s<sup>2</sup>.

**30**)
C

**31**)
Between 0 s and 1 s, the ball moved 5 m, but between 1 s and 2 s, the ball moved 15 m.
The average of these two is 10 m/s, which is the approximate instantaneous speed at 1 s.

**32**)
At point B the velocity is larger.

**33**)
10 m/s for both

**35**)
10 m/s, 20 m/s, 30 m/s

