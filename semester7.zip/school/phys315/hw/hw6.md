Homework F
==========
- Nick Handrick
- Due: 2017-11-13

Chapter 13
----------
- RQ: None
- CE: 2, 3, 6, 15, 16, 17, 19, 21, 23, 24, 26, 28, 29, 30, 32, 33

Solutions
=========

Chapter 13
----------
**Ch11CE2**) We would be less uncertain if Planck's constant were smaller. If it was 0, there would be no uncertainty.

**Ch11CE3**) Everything would be super duper uncertain! I wouldn't be able to tell both how fast and where my baseball
is, let alone my house!

**Ch11CE6**) The thermometer likely has a different temperature than the water, and regardless, some of the energy from
the water goes into the thermometer to take the reading, which lowers the temperature of the water slightly. This is not
due to a quantum effect.

**Ch11CE15**) The double slit experiment, the entanglement experiment, and polarizing light using 3 different polarized
lenses.

**Ch11CE16**) Throwing a softball and measuring its motion, diffracting light, and using a spectrometer.

**Ch11CE17**) A radio measures certain bands of electromagnetic radiation like a spectrometer, but they just happen to
be invisible.

**Ch11CE19**) Spectroscopes use a thin slit so that the shape of the casted light is a slit, which is easier to measure.
It's not unsimilar to why we use a needle for the pointer of a compass instead of say, a circle.

**Ch11CE21**) Based on the color of light emitted from the burning substance.

**Ch11CE23**) The electron is much smaller in mass, which explains why it does all the moving.

**Ch11CE24**) It would look like a triangle or pyramid

**Ch11CE26**) It would look like an X or square

**Ch11CE28**) Yes, the excited one would have a very slightly higher mass added by acceleration due to E=MC<sup>2</sup>.

**Ch11CE29**) Since the energy of the atom decreases, so does the mass slightly.

**Ch11CE30**) E<sub>5</sub> to E<sub>1</sub>.

**Ch11CE32**) E<sub>5</sub> to E<sub>4</sub>, and E<sub>2</sub> to E<sub>1</sub>.

**Ch11CE33**) I can't tell because my book has too dark of ink printed for the spectra graph :(

