Homework H
==========
- Nick Handrick
- Due: 2017-12-13

Chapter 16
----------
- RQ: 11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23
- CE: 2, 3, 4, 23, 28, 29, 35

Chapter 17
----------
- RQ: 2, 3, 4, 5, 6, 7, 8, 11, 12, 13, 17, 19, 22, 26, 27
- CE: 1, 2, 3, 4, 6, 9, 10, 11, 12, 14 + short essay

Solutions
=========

Chapter 16
----------
**Ch16RQ11**)
A nuclear reactor is a device that causes nuclear fission to occur, converting the energy to a more useful form.

**Ch16RQ12**) 
A turbine is not needed in a nuclear power plant.

**Ch16RQ13**)
A cooling tower is needed in a nuclear power plant.

**Ch16RQ14**)
A nuclear reactor needs:
1. A core of a radioactive material that generates heat
2. A turbine, converting steam into rotational energy
3. A cooling mechanism, to bring the spent steam back to a reasonable temperature, to prevent overheating

**Ch16RQ15**)
10%

**Ch16RQ16**)
90%

**Ch16RQ17**)
A fusion reactor would use something like hydrogen for fuel, which can come from the atmosphere

**Ch16RQ18**)
Problems with nuclear power:
1. A meltdown is highly radioactive
2. Could lead to nuclear weapon proliferation
3. Radioactive waste disposal (NIMBY)
4. Workers need much more training
5. Politics

Problems with coal power:
1. Pollution
2. Limited resources
3. Inefficient (relative to nuclear)
4. Few useful byproducts
5. Politics

**Ch16RQ21**)
High-level nuclear waste is highly radioactive spent fuel.
It is currently stored underwater, and will eventually be stored in the Yucca Mountain (hopefully).

**Ch16RQ22**)
At three-mile island, the core partially melted down.

**Ch16RQ23**)
At Chernobyl, the core totally melted down because of a lack of regulation in USSR reactors.

**Ch16CE2**)
Like a factor of 15

**Ch16CE3**)
Wood, Trash, Wind, Hydroelectric

**Ch16CE4**)
Fossil Fuels and burning stuff

**Ch16CE23**)
A nuclear power plant doesn't have a smoke stack because it doesn't emit a smog

**Ch16CE28**)
1. Coal doesn't require extreme precautions to prevent a nuclear meltdown
2. Coal factories can be operated with fewer qualifications/training

**Ch16CE29**)
1. Nuclear power has a much higher energy efficiency
2. Nuclear pollution is more contained

**Ch16CE35**)
Hydroelectric energy is renewable because of the Earth's water cycle

Chapter 17
----------
**Ch17RQ2**)
A field is an n-dimensional space where every point has a measurable value

**Ch17RQ3**)
A quantized field is a field where every measured value is an integer multiple of some constant

**Ch17RQ4**)
Electrons are quanta of the electromagnetic field

**Ch17RQ5**)
A photon is the carrier of the electromagnetic force

**Ch17RQ6**)
17.3(a) has more interactions than 17.3(b), demonstrating how more interactions causes a smoother (more classically
defined) movement

**Ch17RQ7**)
Muons and taus are leptons, just like electrons.

**Ch17RQ8**)
An anti-particle is an antimatter version of a standard model particle.
For example, positrons and antiprotons.

**Ch17RQ11**)
Bubble chambers and the LHC are both used to observe subatomic particles.

**Ch17RQ12**)
Empty space is just space where each field has a measurement of 0 (except the Higgs field).
This could be because of destructive interference though, don't be fooled.

**Ch17RQ13**)
Neutrinos are hard to detect because they only experience the weak force, and only rarely.

**Ch17RQ17**)
The strong force is due to the exchanges of gluons between quarks.

**Ch17RQ19**)
Protons are made up of two up quarks and one down quark.
Electrons are elementary particles.

**Ch17RQ22**)
There are 6 kinds of quarks, of which 2 (up and down) are found in ordinary matter.

**Ch17RQ26**)
A graviton is a theoretical particle that carries the gravitational force.
It has not been experimentally verified.

**Ch17RQ27**)
1 Planck length is how far light travels in 1 Planck time.
It's the barrier between classical and quantum mechanics.

**Ch17CE1**)
The particles have opposite movements.

**Ch17CE2**)
The curly-q ones are moving faster, considering the exposure time of the photograph.

**Ch17CE3**)
Photons are not seen in bubble chambers.

**Ch17CE4**)
Gamma rays, and if they were moving, it would be higher.

**Ch17CE6**)
Only photons travel at light speed, and neutrinos travel near light speed.

**Ch17CE9**)
All except for the neutrinos and Z bosons experience the electromagnetic force.
Only the non-neutrino leptons exchange photons.

**Ch17CE10**)
Neutrino, quark, muon, photon

**Ch17CE11**)
Gluons are similar to photons in how they are force carrier particles and gauge bosons.
They are different in how gluons carry the strong force and photons carry the EM force.

**Ch17CE12**)
Quarks and electrons are both elementary particles and have a charge.
However, electrons are force carriers.

**Ch17CE14**)
The rest of the mass of a proton comes from the gluons that connect the quarks.

