Monroe's motivated sequence
===
Attention
Need
Satisfaction
Visualization
Action

3 Types of Credibility:
===
Initial - Before the speech
Derived - During the speech
Terminal - After the speech

3 Ways to Enhance Credibility
===
Competence - You know what you're talking about
Trustworthiness - Objective and reasonable
Dynamism - Charisma

Ethics
===
Definition: Using standards, morals, and/or values to determine if something is right or wrong

Guidelines:
- Look at your goals
- Be fully prepared
- Use honest, understandable language
- Avoid abusive language/name calling

