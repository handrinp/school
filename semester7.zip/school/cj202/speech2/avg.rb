print "Enter a number: "
num1 = gets.to_i

print "Enter a number: "
num2 = gets.to_i

print "Enter a number: "
num3 = gets.to_i

avg = (num1 + num2 + num3) / 3.0
puts "The average is #{avg}"
