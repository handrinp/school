#include <stdio.h>

int main(int argc, char **argv) {
    int num1;
    printf("Enter a number: ");
    scanf("%d", &num1);

    int num2;
    printf("Enter a number: ");
    scanf("%d", &num2);

    int num3;
    printf("Enter a number: ");
    scanf("%d", &num3);

    float avg = (num1 + num2 + num3) / 3.0f;
    printf("The average is %f\n", avg);
    return 0;
}
