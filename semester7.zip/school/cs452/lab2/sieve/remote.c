#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

typedef unsigned char byte;

// error - wrapper for perror
void error(char *msg) {
    perror(msg);
    exit(1);
}

int isPrime(byte *field, unsigned int n) {
    n = (n >> 1) - 1;
    return (field[n >> 3] >> (n & 7)) & 1;
}

void disableBit(byte *field, unsigned int n) {
    n = (n >> 1) - 1;
    field[n >> 3] &= ~(1 << (n & 7));
}

void printField(byte *field, int start, int n) {
    int j = 0;

    for (int i = start; i < n && j < 10; i += 2) {
        if (isPrime(field, i)) {
            printf("%s%d", j++ ? ", " : "", i);
        }
    }

    if (j == 10) {
        printf("...");
    }

    puts("");
}

unsigned int sieveField(unsigned int curPrime, unsigned int n, byte *field) {
    for (unsigned int i = curPrime + (curPrime << 1); i < n; i += curPrime << 1) {
        disableBit(field, i);
    }

    unsigned int newPrime;

    for (newPrime = curPrime + 2;
            !isPrime(field, newPrime);
            newPrime += 2);

    return newPrime;
}

int main(int argc, char **argv) {
    int parentfd;                  // parent socket
    int childfd;                   // child socket
    int portno;                    // port to listen on
    unsigned int clientlen;        // byte size of client's address
    struct sockaddr_in serveraddr; // server's addr
    struct sockaddr_in clientaddr; // client addr
    struct hostent *hostp;         // client host info
    char *hostaddrp;               // dotted decimal host addr string
    int optval;                    // flag value for setsockopt
    int n;                         // message byte size

    // check command line arguments 
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(1);
    }

    // socket: create the parent socket 
    portno = atoi(argv[1]);
    parentfd = socket(AF_INET, SOCK_STREAM, 0);

    if (parentfd < 0)
        error("ERROR opening socket");

    /* setsockopt: Handy debugging trick that lets 
     * us rerun the server immediately after we kill it; 
     * otherwise we have to wait about 20 secs. 
     * Eliminates "ERROR on binding: Address already in use" error. 
     */
    optval = 1;
    setsockopt(parentfd, SOL_SOCKET, SO_REUSEADDR, (const void *)&optval , sizeof(int));

    // build the server's Internet address
    bzero((char *) &serveraddr, sizeof(serveraddr));

    // this is an Internet address
    serveraddr.sin_family = AF_INET;

    // let the system figure out our IP address
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

    // this is the port we will listen on
    serveraddr.sin_port = htons((unsigned short)portno);

    // bind: associate the parent socket with a port 
    if (bind(parentfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr)) < 0) 
        error("ERROR on binding");

    // listen: make this socket ready to accept connection requests 
    if (listen(parentfd, 5) < 0) // allow 5 requests to queue up
        error("ERROR on listen");

    // main loop: wait for a connection request, echo input line, * then close connection.
    clientlen = sizeof(clientaddr);
    int cont = 1;

    while (cont) {
        // accept: wait for a connection request 
        childfd = accept(parentfd, (struct sockaddr *) &clientaddr, &clientlen);

        if (childfd < 0) 
            error("ERROR on accept");
        
        // gethostbyaddr: determine who sent the message 
        hostp = gethostbyaddr((const char *) &clientaddr.sin_addr.s_addr, sizeof(clientaddr.sin_addr.s_addr), AF_INET);

        if (hostp == NULL)
            error("ERROR on gethostbyaddr");

        hostaddrp = inet_ntoa(clientaddr.sin_addr);

        if (hostaddrp == NULL)
            error("ERROR on inet_ntoa\n");

        // printf("server established connection with %s (%s)\n", hostp->h_name, hostaddrp);
        
        // read: read input string from the client
        unsigned int data[3];
        n = read(childfd, data, 3 * sizeof(unsigned int));

        if (n < 0) 
            error("ERROR reading from socket");
        else if (n == 1)
            cont = 0;
        else {
            byte *buf = (byte *) malloc(data[2] * sizeof(byte));
            n = read(childfd, buf, data[2]);
            printf("Recd: ");
            printField(buf, data[0], data[1]);

            if (n < 0)
                error("ERROR reading from socket");

            // printf("server received %d bytes\n", n);

            unsigned int curPrime = sieveField(data[0], data[1], buf);

            // write: echo the input string back to the client 
            n = write(childfd, &curPrime, sizeof(unsigned int));

            if (n < 0) 
                error("ERROR writing to socket");

            printf("Sent: ");
            printField(buf, curPrime, data[1]);
            printf("To: %s\n", hostaddrp);
            n = write(childfd, buf, data[2]);

            if (n < 0) 
                error("ERROR writing to socket");

            free(buf);
        }

        close(childfd);
    }
}

