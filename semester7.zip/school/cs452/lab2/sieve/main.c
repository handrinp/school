#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 

typedef unsigned char byte;

// error - wrapper for perror
void error(char *msg) {
    perror(msg);
    exit(0);
}

// prototypes for field sieving
int isPrime(byte *field, unsigned int n);
void disableBit(byte *field, unsigned int n);
void parseArgsField(int argc, char **argv, unsigned int *n, unsigned int *nBytes, char **address, int *port, byte **field);
unsigned int sieveField(unsigned int curPrime, unsigned int n, byte *field);
unsigned int sieveFieldRemote(unsigned int curPrime, unsigned int nMax, unsigned int nBytes, byte *field, char *hostname, int portno);
void cleanup(byte *field, char *hostname, int portno);

void printField(byte *field, int start, int n, int all) {
    int j = 0;

    for (int i = start; i < n && (all || j < 10); i += 2) {
        if (isPrime(field, i)) {
            printf("%s%d", j++ ? ", " : "", i);
        }
    }

    if (!all && j == 10) {
        printf("...");
    }

    puts("");
}

int main(int argc, char **argv) {
    unsigned int n, curPrime = 3, nBytes;
    int port;
    char *address;
    byte *field;
    parseArgsField(argc, argv, &n, &nBytes, &address, &port, &field);

    for (unsigned int i = 0; curPrime * curPrime <= n; ++i) {
        curPrime = (i & 1) ? sieveField(curPrime, n, field)
                : sieveFieldRemote(curPrime, n, nBytes, field, address, port);
    }

    printf("\nPrimes found: 2, ");
    printField(field, 3, n, 1);
    cleanup(field, address, port);
    return 0;
}

int isPrime(byte *field, unsigned int n) {
    n = (n >> 1) - 1;
    return (field[n >> 3] >> (n & 7)) & 1;
}

void disableBit(byte *field, unsigned int n) {
    n = (n >> 1) - 1;
    field[n >> 3] &= ~(1 << (n & 7));
}

void parseArgsField(int argc, char **argv, unsigned int *n, unsigned int *nBytes, char **address, int *port, byte **field) {
    // expect 4 args
    if (argc != 4) {
        fprintf(stderr, "usage: \"%s <n> <address> <port>\"\n", argv[0]);
        exit(1);
    }

    // parse variables from the args
    *n = strtoul(argv[1], NULL, 0);
    *address = argv[2];
    *port = atoi(argv[3]);

    // expect n to be at least 3
    if (*n < 3) {
        puts("n must be at least 3.");
        exit(1);
    }

    int nBits = (*n - 1) >> 1;
    *nBytes = (nBits >> 3) + (nBits & 7 ? 1 : 0);
    int errBits = nBits & 7;
    *field = (byte *) malloc(*nBytes * sizeof(byte));

    // fill the field with 1 bits
    for (int i = 0; i < *nBytes; ++i) {
        (*field)[i] = 0xFF;
    }

    // get rid of the extra bits
    (*field)[*nBytes - 1] &= (0xFF >> errBits);
}

unsigned int sieveField(unsigned int curPrime, unsigned int n, byte *field) {
    for (unsigned int i = curPrime + (curPrime << 1); i < n; i += curPrime << 1) {
        disableBit(field, i);
    }

    unsigned int newPrime;

    for (newPrime = curPrime + 2;
            !isPrime(field, newPrime);
            newPrime += 2);

    return newPrime;
}

unsigned int sieveFieldRemote(unsigned int curPrime, unsigned int nMax, unsigned int nBytes, byte *field, char *hostname, int portno) {
    int sockfd, n;
    struct sockaddr_in serveraddr;
    struct hostent *server;

    // socket: create the socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");

    // gethostbyname: get the server's DNS entry
    server = gethostbyname(hostname);

    if (server == NULL) {
        fprintf(stderr, "ERROR, no such host as %s\n", hostname);
        exit(0);
    }

    // build the server's Internet address
    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serveraddr.sin_addr.s_addr, server->h_length);
    serveraddr.sin_port = htons(portno);

    // connect: create a connection with the server
    if (connect(sockfd, (const struct sockaddr *) &serveraddr, sizeof(serveraddr)) < 0)
      error("ERROR connecting");

    // send the message line to the server
    unsigned int data[3] = {curPrime, nMax, nBytes};
    n = write(sockfd, data, 3 * sizeof(unsigned int));

    if (n < 0) 
      error("ERROR writing to socket");

    printf("Sent: ");
    printField(field, curPrime, nMax, 0);
    printf("To: %s\n", hostname);
    n = write(sockfd, field, data[2]);

    if (n < 0) 
      error("ERROR writing to socket");

    int newPrime;
    n = read(sockfd, &newPrime, sizeof(int));

    if (n < 0)
      error("ERROR reading from socket");

    n = read(sockfd, field, nBytes);
    printf("Recd: ");
    printField(field, newPrime, nMax, 0);

    if (n < 0)
      error("ERROR reading from socket");

    close(sockfd);
    return newPrime;
}

void cleanup(byte *field, char *hostname, int portno) {
    free(field);

    // close the remote
    int sockfd, n;
    struct sockaddr_in serveraddr;
    struct hostent *server;

    // socket: create the socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0)
        error("ERROR opening socket");

    // gethostbyname: get the server's DNS entry
    server = gethostbyname(hostname);

    if (server == NULL) {
        fprintf(stderr, "ERROR, no such host as %s\n", hostname);
        exit(0);
    }

    // build the server's Internet address
    bzero((char *) &serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serveraddr.sin_addr.s_addr, server->h_length);
    serveraddr.sin_port = htons(portno);

    // connect: create a connection with the server
    if (connect(sockfd, (const struct sockaddr *) &serveraddr, sizeof(serveraddr)) < 0)
      error("ERROR connecting");

    // send the message line to the server
    char data[1] = {0};
    n = write(sockfd, data, 1);

    if (n < 0) 
      error("ERROR writing to socket");

    close(sockfd);
}

