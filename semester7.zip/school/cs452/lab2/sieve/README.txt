SIEVE OF ERATOSTHENES

To compile:
    on both machines:
            make

To run*:
    on the remote:
            ./remote 9479
    on the main computer:
            ./main 10000 thing2.cs.uwec.edu 9479


* Assuming the remote computer has the address "thing2.cs.uwec.edu",
  we are using port 9479, and we want to find primes < 10000

