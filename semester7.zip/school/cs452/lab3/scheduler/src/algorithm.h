class Algorithm {
    public:
        virtual void tick();
        virtual void schedule();
    private:
};
