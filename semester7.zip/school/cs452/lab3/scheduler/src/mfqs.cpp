#include "algorithm.h"

class MFQS : public Algorithm {
    public:
        void tick() {

        }

        void schedule() {

        }
    private:
};
