#include <iostream>
#include <vector>

int prompt(string prompt, vector<string> opts);

int main(int argc, char **argv) {
    cout << "Welcome to Nick H's scheduler" << endl;

    int choice = prompt("Which algorithm would you like to try?", {
        "MFQS (Multi-level Feedback Queue Scheduler)",
        "RTS (Real-Time Scheduler)",
        "WHS (Windows Hybrid Scheduler)"
    });

    cout << "You chose: " << choice << endl;
    return 0;
}

int prompt(string prompt, vector<string> opts) {
    int valid = 0;
    unsigned int choice;

    while (!valid) {
        cout << prompt << endl;

        for (unsigned int i = 0; i < opts.size(); ++i) {
            cout << "  " << i << ") " << opts[i] << endl;
        }

        cout << "> ";
        cin >> choice;
        cout << endl;

        if (!(valid = choice < opts.size())) {
            cout << "Invalid choice. Try again." << endl << endl;
        }
    }

    return choice;
}
