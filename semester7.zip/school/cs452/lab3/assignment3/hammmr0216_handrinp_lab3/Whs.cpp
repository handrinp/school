#include "main.h"

Whs::Whs(vector<Process> procs) {
    // stable_sort(procs.begin(), procs.end(), byArrival);
    int tq;
    bool valid = false;

    while (!valid) {
        cout << "What would you like the time quantum to be?" << endl << "> ";
        cin >> tq;
        valid = tq > 0;

        if (!valid) {
            cout << "Time quantum must be positive" << endl << endl;
        }
    }

    vector<deque<Process>> queues;

    vector<Process> done;
    int timer = 0;
    Process curProc;
    bool finished = false;

    while (!finished) {
        // handle new arrivals
        while (!procs.empty() && (curProc = procs.back()).getArrival() <= timer) {
            queues[0].push_back(curProc);
            procs.pop_back();
#ifdef debug
            cout << "Process " << curProc.getPID() << " arrived at time " << curProc.getArrival() <<
                    " and started at time " << timer << endl;
#endif
        }
    }

    int numProcs = done.size();
    double factor = 1.0 / numProcs;
    long totalWaitTime = 0;
    long totalTurnaroundTime = 0;
    cout << endl << "Finished scheduling " << numProcs << " processes! Here are the stats:" << endl;

    for (unsigned int i = 0; i < done.size(); ++i) {
        totalWaitTime += done[i].getWaitTime();
        totalTurnaroundTime += done[i].getTurnaroundTime();
    }

    cout << "Average wait time: " << (totalWaitTime * factor) << endl <<
            "Average turnaround time: " << (totalTurnaroundTime * factor) << endl;
}

//Destructor
Whs::~Whs() {}

//Utility
//handy way to print errors
void Whs::callError(const char* words, bool exitApp) {
    printf("Whs Error:");
    perror(words);
    if (exitApp) exit(1);
}
