#ifndef RTS_H
#define RTS_H

#include <stdlib.h>
#include <deque>
#include "Process.h"

class Rts
{
    public:
        Rts(vector<Process> p);
        ~Rts();
        void tick();
        int getTimeSpent();
        void pushHighestToTop();
    protected:
        void callError(const char* words, bool exitApp);
        vector<Process> procs;
        vector<Process> done;
        deque<Process> procQueue;
        char hardSoft;
        unsigned int jobsLoaded;
        unsigned int jobsRan;
        bool hardRealTimeStop;
        int ticksPast;
        Process *p;
        int timer;
    private:
};

#endif // RTS_H
