
#ifndef PROCESS_H
#define PROCESS_H

class Process
{
    public:
        Process(int P_ID, short burst, int arrival, int priority, int deadline, int io);
        Process();
        ~Process();
        //getters
        int getPID();
        short getBurst();
        int getArrival();
        int getPriority();
        int getDeadline();
        int getIo();
        int getTime();
        int getEnd();
        int getTurnaroundTime();
        int getWaitTime();
        int getTimeRemaining();
        int getAgedTime();
        bool getWasCancelled();
        //setters
        void setPID(int P_ID);
        void setBurst(short burst);
        void setArrival(int arrival);
        void setPriority(int priority);
        void setDeadline(int deadline);
        void setTimeRemaining(int timeRemaining);
        void setIo(int io);
        void setEnd(int end);
        void setAgedTime(int agedTime);
        void setWasCancelled();

        static bool compareDeadline(Process p1, Process p2);
        static bool comparePriorities(Process p1, Process p2);
    protected:
        int P_ID;
        short originalBurst;
        short burst;
        int arrival;
        int priority;
        int deadline;
        int timeRemaining;
        int io;
        int end;
        int agedTime;
        bool wasCancelled;
    private:
};

#endif // PROCESS_H
