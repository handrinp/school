#include "main.h"

Mfqs::Mfqs(vector<Process> p) {
    cout << "Here we go with " << p.size() << " processes" << endl;
    procs = p;
    bool valid = false;

    while (!valid) {
        cout << "How many queues would you like? Enter a number between 2 and 5" << endl << "> ";
        cin >> numQueues;
        valid = numQueues >= 2 && numQueues <= 5;

        if (!valid) {
            cout << "Invalid number of queues" << endl << endl;
        }
    }

    int lastQueue = numQueues - 1;

    queues = vector<deque<Process>>();
    vector<Process> done;

    for (int i = 0; i < numQueues; ++i) {
        queues.push_back(deque<Process>());
    }

    valid = false;

    while (!valid) {
        cout << "Enter a time quantum for the initial queue: " << endl << "> ";
        cin >> tQuant;
        valid = tQuant > 0;

        if (!valid) {
            cout << "Time quantum must be positive" << endl << endl;
        }
    }

    int maxAgedTime;
    valid = false;

    while (!valid) {
        cout << "Enter the aging time for processes in the last queue: " << endl << "> ";
        cin >> maxAgedTime;
        valid = maxAgedTime > 0;

        if (!valid) {
            cout << "Max aging time must be positive" << endl << endl;
        }
    }

    int timer = 0;
    Process curProc, unfinishedProc;
    bool finished = false;

    while (!finished) {
        // add newly arrived procs to the first queue
        while (!procs.empty() && (curProc = procs.back()).getArrival() <= timer) {
            queues[0].push_back(curProc);
            procs.pop_back();
#ifdef debug
            cout << "Process " << curProc.getPID() << " arrived at time " << curProc.getArrival() << endl;
#endif
        }

        // check the queues in order for the next process to run
        bool gotToRun = false;

        for (int i = 0; !gotToRun && i < lastQueue; ++i) {
            if ((gotToRun = !queues[i].empty())) {
                // run the first proc
                curProc = queues[i].front();
                queues[i].pop_front();
                int runFor = tQuant << i;
                bool finishedProc = curProc.getBurst() <= runFor;

                // finish the process
                if (finishedProc) {
                    runFor = curProc.getBurst();
                    timer += runFor;
#ifdef debug
                    cout << "Process " << curProc.getPID() << " ran for " << runFor << " and finished" << endl;
#endif
                    curProc.setEnd(timer);
                    curProc.setBurst(0);
                    done.push_back(curProc);
                } else {
                    unfinishedProc = curProc;
                }

                // age the processes in the last queue
                for (unsigned int i = 0; i < queues[lastQueue].size(); ++i) {
                    curProc = queues[lastQueue][i];
                    curProc.setAgedTime(runFor + curProc.getAgedTime());
                }

                // promote all the elderly procs
                while (!queues[lastQueue].empty() && (curProc = queues[lastQueue].front()).getAgedTime() >= maxAgedTime) {
                    curProc.setAgedTime(0);
                    queues[lastQueue - 1].push_back(curProc);
                    queues[lastQueue].pop_front();
#ifdef debug
                    cout << "Process " << curProc.getPID() << " aged from the last queue leaving " <<
                            queues[lastQueue].size() << " left" << endl;
#endif
                }

                // run the process but don't finish it, and then demote it
                if (!finishedProc) {
                    curProc = unfinishedProc;
                    timer += runFor;
                    curProc.setBurst(curProc.getBurst() - runFor);

                    // put it in the next queue
                    queues[i + 1].push_back(curProc);

#ifdef debug
                    cout << "Process " << curProc.getPID() << " ran for " << runFor << " but was demoted to queue " <<
                            (i + 1) << " because it had " << curProc.getBurst() << " left, leaving " <<
                            queues[i + 1].size() << " in queue " << (i + 1) << endl;
#endif
                }
            }
        }

        // none of the round robin queues had work to do - check out the fcfs queue
        if (!gotToRun) {
            if (queues[lastQueue].empty()) {
                if (procs.empty()) {
                    // we are done here
                    finished = true;
                } else {
                    // waiting
                    ++timer;
                }
            } else {
                curProc = queues[lastQueue].front();
                queues[lastQueue].pop_front();
                int runFor = curProc.getBurst();
                curProc.setBurst(0);
                timer += runFor;
#ifdef debug
                cout << "Process " << curProc.getPID() << " ran for " << runFor << " in the last queue and finished" <<
                        endl;
#endif
                curProc.setEnd(timer);
                done.push_back(curProc);
            }
        }
    }

    int numProcs = done.size();
    double factor = 1.0 / numProcs;
    long totalWaitTime = 0;
    long totalTurnaroundTime = 0;
    cout << endl << "Finished scheduling " << numProcs << " processes! Here are the stats:" << endl;

    for (unsigned int i = 0; i < done.size(); ++i) {
        totalWaitTime += done[i].getWaitTime();
        totalTurnaroundTime += done[i].getTurnaroundTime();
    }

    cout << "Average wait time: " << (totalWaitTime * factor) << endl <<
            "Average turnaround time: " << (totalTurnaroundTime * factor) << endl;
}

//Destructor
Mfqs::~Mfqs() {
}

//Utility
//getters
int Mfqs::getTimeQuantum() {
    return this->tQuant;
}

//setters
void Mfqs::setTimeQuantum(int tq) {
    this->tQuant = tq;
}

//handy way to print errors
void Mfqs::callError(const char* words, bool exitApp) {
    printf("Mfqs Error: ");
    perror(words);

    if (exitApp) {
        exit(1);
    }
}

