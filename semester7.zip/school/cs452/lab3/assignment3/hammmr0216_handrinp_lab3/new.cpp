 while(this->hasUnfinishedJobs() && !hardRealTimeStop){
  
    if(softOrHard == 'h' && p->getTimeRemaining() + clock > p->getDeadline()){ //hard real time mode is active. stop scheduler loop now if a process can't finish
	  hardRealTimeStop = true;
	  cout << "Process " << p->getPID() << " cancelled. Shutting down." << endl;
	  
	} else {

		while(p != NULL && p->getTimeRemaining() + clock > p->getDeadline()){ //remove any and all processes that can't finish by deadline
		  p->setState(Process::TERMINATED); //terminates current active process. since p is a pointer, it is set as terminated in the scheduler's list as well  
		  //Count a process as having ran for calculating average wait/turnaround times
		  if(p->getTimeRemaining() != p->getBurst()){
		    jobsRan++;
		  }
		  
		  //load the next process, if there is one in rtsQueue
		  if(rtsQueue.size() > 0){
			p = rtsQueue.front();
			rtsQueue.pop_front();
		  } else {
			p = NULL;
		  }
		  
		  
		}

		//CLOCK TICK, reduce time remaining on active process
		if(p != NULL){
		  p->setTimeRemaining(p->getTimeRemaining() - 1);
		}
	
		//increment wait times of all processes loaded in thus far
		for(int i = 0; i < (int)rtsQueue.size(); i++){
		  Process* p2 = rtsQueue.at(i);
		  p2->addTimeWaiting(1);
		}

		//advance the clock, last part of CLICK TICK (occurs with or without an active process)
		clock++;
		//check if the current process is done (if one is active)
		if(p != NULL && p->getTimeRemaining() == 0){

		  p->setFinishTime(clock);
		  p->setState(Process::TERMINATED);
		  jobsRan++;
		  //pop next process from rtsQueue, if there is one
		  if(rtsQueue.size() > 0){
			p = rtsQueue.front();
			rtsQueue.pop_front();
			
		  } else if(jobsLoaded < (int)this->processes.size()){  //otherwise, advance the clock to when the next process arrives and empty p so it doesn't go back into rtsQueue
            clock = this->processes.at(jobsLoaded)->getArrivalTime();
			p = NULL;
		  }
		//if there is no active process, we can advance the clock immediately to the arrival time of the next process to be loaded in (if there's one to load)
		} else if(p == NULL && jobsLoaded < (int)this->processes.size()){ 
		  clock = this->processes.at(jobsLoaded)->getArrivalTime();
		}



	  //check if a process has "arrived" (unless we loaded them all)
	  if(jobsLoaded < (int)this->processes.size() && this->processes.at(jobsLoaded)->getArrivalTime() == clock){
	  //This was omitted: causes errors when p is null
	  //cout << "Process " << this->processes.at(jobsLoaded)->getPID() << " has arrived. Deadlines: " << p->getDeadline() << " " << this->processes.at(jobsLoaded)->getDeadline() << endl;

	  //put currently active process (if we have one) back in the queue in case it needs to be replaced with a process with a shorter deadline. We'll end up pulling it back out if it doesn't
	  if(p != NULL){
	    rtsQueue.push_back(p);
	  }

		while(jobsLoaded < (int)this->processes.size() && this->processes.at(jobsLoaded)->getArrivalTime() == clock){

			if(this->processes.at(jobsLoaded)->getDeadline() >= this->processes.at(jobsLoaded)->getBurst() + clock){ //process can finish by deadline

			  rtsQueue.push_back(this->processes.at(jobsLoaded));
			  this->processes.at(jobsLoaded)->setState(Process::READY_TO_RUN);
			  jobsLoaded++;

			} else { //process can't finish by deadline

			  if(softOrHard == 'h'){ //hard real time mode: stop everything
			    hardRealTimeStop = true;
	            cout << "Process " << this->processes.at(jobsLoaded)->getPID() << " cancelled. Shutting down." << endl;
				clock = -1; //forces while loop to end
			  } else { //soft real time mode: report this process and load the next one
			    this->processes.at(jobsLoaded)->setState(Process::TERMINATED);
			    jobsLoaded++;
			  }
			}

		  
	    }
		
		//Order processes by deadline again and make the lowest deadline process active (unless hard real time is stopping RTS)
		if(!hardRealTimeStop){
		  sort(rtsQueue.begin(), rtsQueue.end(), Process::compareDeadline);
		  p = rtsQueue.front();
		  rtsQueue.pop_front();
		}
      }
    }
  }
  this->totalProcessesRan = jobsRan;
}