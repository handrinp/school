Scheduler Lab
=============
This is a program that can be used to emulate various scheduling algorithms, including Multi-level Feedback Queue
Scheduling (MFQS), and Real Time Scheduling (RTS). We did not get around to implementing the Windows Hybrid Scheduler.

Specifications
==============
This program uses a standard specification for its input files. Each input file consists of a header row followed by
lines of process fields. The first line (the header) is ignored by the program. Each line after that must look like this:
```
<pid>	<burst>	<arrival>	<priority>	<deadline>	<I/O>
```
where each of the fields are a signed integer. The values are separated by a tab character (`\t`). Invalid process lines
are ignored/sanitized.

To Compile
==========
Run `make`. It's that simple :)

To Run
======
Run `./main <filename>`, where "filename" is a path to an input file of processes.

