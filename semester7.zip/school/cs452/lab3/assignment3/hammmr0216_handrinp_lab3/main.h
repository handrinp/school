#include <stdio.h>
#include <errno.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include "UntrustedLib.h"
#include "Process.h"
#include "Mfqs.h"
#include "Rts.h"
#include "Whs.h"

//#define debug 1

using namespace std;

#define CHOICE_MFQS 0
#define CHOICE_RTS  1
#define CHOICE_WHS  2

int prompt(string prompt, vector<string> opts);
bool byArrival(Process p1, Process p2);
bool byArrivalRts(Process p1, Process p2);
