#include <cstring>
#include <string>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <sstream>
#include <vector>
#include "UntrustedLib.h"

using namespace std;

//My special "Untrustedlib" which is a static class i use to hold static methods, (its untriusted becaus ethe nam ei us eon the internet is Untrustedlife)
char *UntrustedLib::my_strdup(const char *str)
    {
    size_t len = strlen(str);
    char *x = (char *)malloc(len+1); /* 1 for the null terminator */
    if(!x) return NULL; /* malloc could not allocate memory */
    memcpy(x,str,len+1); /* copy the string into the new buffer */
    return x;
    }

std::string UntrustedLib::getDirection(int x, int y, int x2, int y2)
    {
                std::string direction="";
                if (y>y2)
                    {
                    direction+="south";
                    }
                if (y<y2)
                    {
                    direction+="north";
                    }
                if (x>x2)
                    {
                    direction+="east";
                    }
                if (x<x2)
                    {
                    direction+="west";
                    }
                    return direction;
    }

void UntrustedLib::printList(int *sieveList)
{
  int size = sieveList[0];
  int i = 1;
  if (sieveList[0] <= 3)
    {
    //print list if less or equal to 3
    for (i=1; i <= size; i++)
        {
        if (i != size)
        {
        cout << sieveList[i] << ", ";
        }
        else
            {
            cout << sieveList[i];
            }
        }
    cout << endl;
    }
  else
    {
    //otherwise print it the cool way
    for (i=1; i <= 3; i++)
        {
        if (i != 3)
        {
        cout << sieveList[i] << ", ";
        }
        else
            {
            cout << sieveList[i];
            }
        }
    cout << "...";
    for (i = size-3; i < size; i++)
        {
        if (i != size)
        {
        cout << sieveList[i] << ", ";
        }
        else
            {
            cout << sieveList[i];
            }
        }
    }
  cout << endl;
}

// Prints all primes
void UntrustedLib::printMainListAll(vector<int> mainList, int start)
    {
    int i = 0;
    int startLoc = 0;
        while (start > mainList[i])
            {
            startLoc = i+1;
            i++;
            }
        int length = mainList.size();
        for (i = startLoc; i < length; i++)
            {
        if (i != length)
        {
        cout << mainList[i] << ", ";
        }
        else
            {
            cout << mainList[i];
            }
            }
  cout << endl;
    }

//print shortened list of primes
void UntrustedLib::printMainListShort(vector<int> mainList, int start)
    {
    int size = mainList.size();
    int i = 0;
    int startLoc = 0;
    while (start > mainList[i])
        {
        startLoc = i+1;
        i++;
        }
  if (startLoc >= (size-6))
    {
    //print whole list if less then 6
    for (i = startLoc; i < size; i++)
        {
        if (i != size-1)
        {
        cout << mainList[i] << ", ";
        }
        else
            {
            cout << mainList[i];
            }
        }
  }
  else
    {
    for (i = startLoc; i < (startLoc+3); i++)
        {
        if (i != startLoc+2)
        {
        cout << mainList[i] << ", ";
        }
        else
            {
            cout << mainList[i];
            }
        }
     cout << "...";
    for (i = size-3; i < size; i++)
        {
        if (i != size-1)
        {
        cout << mainList[i] << ", ";
        }
        else
            {
            cout << mainList[i];
            }
        }
  }
  cout << endl;
}

