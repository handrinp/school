#include "main.h"

int main(int argc, char **argv) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <input-file>" << endl;
        return 1;
    }

    ifstream inFile;
    inFile.open(argv[1]);

    if (!inFile.is_open()) {
        perror("Error while opening file");
        return 1;
    }

    cout << "Welcome to Mike Hamm and Nick Handrick's scheduler" << endl;

    vector<string> choices = {
        "MFQS (Multi-level Feedback Queue Scheduler)",
        "RTS (Real-Time Scheduler)",
        "WHS (Windows Hybrid Scheduler)"
    };

    int choice = prompt("Which algorithm would you like to try?", choices);
    cout << "Using " << choices[choice] << endl;
    string line;
    vector<Process> procs;
    getline(inFile, line); // ignore the first line of input
    cout << "Loading " << argv[1] << "..." << endl;

    while (getline(inFile, line)) {
        stringstream lineInts(line);
        int pid, arr, pri, dline, io;
        short bst;
        lineInts >> pid;
        lineInts >> bst;
        lineInts >> arr;
        lineInts >> pri;
        lineInts >> dline;
        lineInts >> io;
        bool valid = true;

        // do error checking here, ignore any processes that are invalid for the chosen scheduler
        switch (choice) {
        case CHOICE_MFQS:
            valid = pid > 0 && bst > 0 && arr >= 0 && pri >= 0 && io >= 0;
            break;
        case CHOICE_RTS:
            valid = dline > 0 && bst > 0 && arr >= 0 && bst < dline && dline > arr && bst+arr < dline;
            break;
        case CHOICE_WHS:
            break;
        }

        if (valid) {
            procs.push_back(Process(pid, bst, arr, pri, dline, io));
        }
    }

    if (inFile.bad()) {
        perror("Error while reading file");
        return 1;
    }

    inFile.close();
    cout << "Sorting processes by arrival time..." << endl;

    if (choice == CHOICE_MFQS) {
        stable_sort(procs.begin(), procs.end(), byArrival);
        Mfqs algorithm(procs);
    } else if (choice == CHOICE_RTS) {
		stable_sort(procs.begin(), procs.end(), byArrivalRts);
        Rts algorithm(procs);
    } else if (choice == CHOICE_WHS) {
        stable_sort(procs.begin(), procs.end(), byArrival);
        Whs algorithm(procs);
    }

    return 0;
}

bool byArrival(Process p1, Process p2) {
    return p1.getArrival() > p2.getArrival();
}

bool byArrivalRts(Process p1, Process p2) {
    return p1.getArrival() < p2.getArrival();
}


bool byAge(Process p1, Process p2) {
    return p1.getAgedTime() < p2.getAgedTime();
}

int prompt(string prompt, vector<string> opts) {
    int valid = 0;
    unsigned int choice;

    while (!valid) {
        cout << prompt << endl;

        for (unsigned int i = 0; i < opts.size(); ++i) {
            cout << "  " << i << ") " << opts[i] << endl;
        }

        cout << "> ";
        cin >> choice;
        cout << endl;

        if (!(valid = choice < opts.size())) {
            cout << "Invalid choice. Try again." << endl << endl;
        }
    }

    return choice;
}
