#include "Process.h"

//constructor
Process::Process(int P_ID, short burst, int arrival, int priority, int deadline, int io)
    {
        setPID(P_ID);
        setBurst(burst);
        setArrival(arrival);
        setPriority(priority);
        setDeadline(deadline);
        setIo(io);
        originalBurst = burst;
		timeRemaining = burst;
        agedTime = 0;
        wasCancelled = false;
    }

Process::Process()
    {

    }

//Destructor
Process::~Process() {}

//getter
bool Process::getWasCancelled() {
    return this->wasCancelled;
}

int Process::getPID()
    {
        return this->P_ID;
    }

short Process::getBurst()
    {
        return this->burst;
    }

int Process::getArrival()
    {
        return this->arrival;
    }

int Process::getPriority()
    {
        return this->priority;
    }
int Process::getDeadline()
    {
        return this->deadline;
    }
int Process::getIo()
    {
        return this->io;
    }
int Process::getTime()
    {
        return this->arrival-burst;
    }
int Process::getEnd()
    {
        return this->end;
    }
int Process::getTurnaroundTime()
    {
        return this->end - this->arrival;
    }
int Process::getWaitTime()
    {
        return getTurnaroundTime() - this->originalBurst;
    }
int Process::getTimeRemaining()
    {
    return this->timeRemaining;
    }
int Process::getAgedTime()
    {
    return this->agedTime;
    }


//setters
void Process::setPID(int P_ID)
    {
      this->P_ID = P_ID;
    }

void Process::setBurst(short burst)
    {
      this->burst = burst;
    }

void Process::setArrival(int arrival)
    {
    this->arrival = arrival;
    }

void Process::setPriority(int priority)
    {
    this->priority = priority;
    }

void Process::setDeadline(int deadline)
    {
    this->deadline = deadline;
    }

void Process::setTimeRemaining(int timeRemaining)
    {
    this->timeRemaining = timeRemaining;
    }
//need this comparator for RTS
bool Process::compareDeadline(Process p1, Process p2)
    {
      if (p1.getDeadline() == p2.getDeadline())
        {
          return (p1.getPID() < p2.getPID());
        }
      else
        {
          return (p1.getDeadline() < p2.getDeadline());
        }
    }

bool Process::comparePriorities(Process p1, Process p2)
    {
      if (p1.getPriority() == p2.getPriority())
        {
          return (p1.getPID() < p2.getPID());
        }
      else
        {
          return (p1.getPriority() < p2.getPriority());
        }
    }
void Process::setIo(int io)
    {
    this->io = io;
    }
void Process::setEnd(int end)
    {
    this->end = end;
    }
void Process::setAgedTime(int agedTime)
    {
    this->agedTime = agedTime;
    }
void Process::setWasCancelled() {
    this->wasCancelled = true;
}
