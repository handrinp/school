#ifndef UNTRUSTEDLIB_H
#define UNTRUSTEDLIB_H
#include <vector>
#include <string>

class UntrustedLib
{
    public:
        static char *my_strdup(const char *str);
        static std::string getDirection(int x, int y, int x2, int y2);
        static void printList(int *sieveList);
        static void printMainListAll(std::vector<int> masterList, int start);
        static void printMainListShort(std::vector<int> masterList, int start);
    protected:
    private:
};

#endif // UNTRUSTEDLIB_H
