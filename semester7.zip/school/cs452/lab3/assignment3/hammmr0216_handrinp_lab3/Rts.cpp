#include "main.h"
#include <vector>
#include <iostream>
#include <algorithm>
#include <deque>
#include <sys/time.h>

Rts::Rts(vector<Process> p2) {
    procs=p2;
    bool valid=false;
    jobsLoaded = 0;
    jobsRan = 0;
    hardRealTimeStop = false;
    timer = 0;

    using namespace std;

    cout << "Here we go with " << p2.size() << " processes" << endl;

    while (!valid) {
        printf("(s)oft or (h)ard?\n");
        cin >> hardSoft;
        valid = (hardSoft == 's' || hardSoft == 'h');

        if (!valid) {
           printf("Invalid letter, must be s (soft) or h (hard)\n");
        }
    }

    struct timeval tp;
    gettimeofday(&tp, NULL);
    long millisStart = tp.tv_sec * 1000 + tp.tv_usec / 1000;

    //fill deque from vector
    deque<Process> procQueue;
#ifdef debug
    printf("procqueue set timer\n");
    printf("procqueue size %ld\n", procQueue.size());
#endif
    fflush(stdout);  

    // jump timer ahead to the next arrival
    if (jobsLoaded < procs.size() && procs.at(jobsLoaded).getArrival() != timer) {
        timer = procs.at(jobsLoaded).getArrival();
    }
    
    // several arriving at the same time
    while(jobsLoaded < this->procs.size() && this->procs.at(jobsLoaded).getArrival() == timer) {
        //we should see if processes may be able to complete within the deadline
        //I'm wondering if we should try to predict if a process won't finish due to so many other processes being loaded...
        if(this->procs.at(jobsLoaded).getDeadline() >= timer + this->procs.at(jobsLoaded).getBurst()) { //burst < deadline
            procQueue.push_back(this->procs.at(jobsLoaded)); //process is added to getArrival, making it READY
            jobsLoaded++;
        }
    }
    
    //printf("procqueue size %d\n", procQueue.size());
    //fflush(stdout);  
    //sort procQueue by deadline (possibly slow, but 100k processes finishes within 3 minutes without output, so it's not so bad)
    sort(procQueue.begin(), procQueue.end(), Process::compareDeadline);
    //in preparation to run RTS, pop the first process off of procQueue (earliest PID with shortest deadline)
    p = &procQueue.front();
    procQueue.pop_front();

    while(jobsRan < procs.size() && !hardRealTimeStop) {
#ifdef debug
        cout << timer << endl;
#endif
        tick();
    }

    //stats here
    int numProcs = done.size();
    double factor = 1.0 / numProcs;
    long totalWaitTime = 0;
    long totalTurnaroundTime = 0;
    cout << endl << "Finished scheduling " << numProcs << " processes in real time! Here are the stats:" << endl;

    for (unsigned int i = 0; i < done.size(); ++i) {
        if (!done[i].getWasCancelled()) {
            totalWaitTime += done[i].getWaitTime();
            totalTurnaroundTime += done[i].getTurnaroundTime();
        }
    }

    cout << "Average wait time: " << (totalWaitTime * factor) << endl <<
            "Average turnaround time: " << (totalTurnaroundTime * factor) << endl <<
            "Jobs loaded: " << (jobsLoaded) << endl <<
            "Jobs Ran: " << (jobsRan) << endl;

    gettimeofday(&tp, NULL);
    long millisEnd = tp.tv_sec * 1000 + tp.tv_usec / 1000;
    cout << "Time to run: " << (millisEnd - millisStart) << "ms" << endl;
}

void Rts::tick() {
    //how many ticks have past
    // printf("ticked\n");
    // fflush(stdout); 
    //tick the process
    if (p == NULL && !procQueue.empty()) {
        p = &procQueue.front();
        procQueue.pop_front();
    }

    if(p != NULL && hardSoft == 'h' && p->getTimeRemaining() + timer > p->getDeadline()) { 
         //hard real time mode is active. stop scheduler loop now if a process can't finish
        hardRealTimeStop = true;
        cout << "Process " << p->getPID() << " cancelled. Shutting down." << endl;
        return;
    }

    //printf("Check time remaining against deadline\n");
    //fflush(stdout);  
    while(p != NULL && p->getTimeRemaining() + timer > p->getDeadline()) {
        //remove any and all processes that can't finish by deadline
#ifdef debug
        printf("Push back\n");
#endif
        fflush(stdout);
        p->setEnd(timer);
#ifdef debug
        cout << "Process " << p->getPID() << " cancelled." << endl;
#endif
        p->setWasCancelled();
        done.push_back(*p);
        //Count a process as having ran for calculating average wait/turnaround times
        if(p->getTimeRemaining() != p->getBurst()) {
            jobsRan++;
        }
        //printf("load next process\n");
        //fflush(stdout); 
        //load the next process, if there is one in procQueue
        if(!procQueue.empty()) {
            //printf("popped\n");
            //fflush(stdout); 
            p = &(procQueue[0]);
            procQueue.pop_front();
        } else {
            //printf("setting p to null cause reasons\n");
            //fflush(stdout); 
            p=NULL;
        }
    }

    //printf("Reduce time remaining\n");
    //fflush(stdout);  
    //reduce time remaining
    if(p != NULL){
        p->setTimeRemaining(p->getTimeRemaining() - 1);
    }

    //advance the clock, last part of tick
    //no matter what
    timer++;

    //check if the current process is done (if one is active)
    if(p!=NULL && p->getTimeRemaining() <= 0){
        //add to list of finished processes
        p->setEnd(timer);
        done.push_back(*p);
        jobsRan++;
        //pop next process from procQueue, if there is one
        if(procQueue.size() > 0) {
            p = &procQueue.front();
            procQueue.pop_front();
        } else if(jobsLoaded < this->procs.size()) {
            //otherwise, advance the clock to when the next process arrives and empty p so it doesn't go back into rtsQueue
            timer = this->procs[jobsLoaded].getArrival();
            p = NULL;
        }
    //if there is no active process, we can advance the clock immediately to the arrival time of the next process to be loaded in (if there's one to load)
    } else if(p == NULL && jobsLoaded < this->procs.size()) {
        timer = this->procs[jobsLoaded].getArrival();
    }

    //check if a process has "arrived" (unless we loaded them all)
    if(jobsLoaded < this->procs.size() && this->procs[jobsLoaded].getArrival() == timer){
        if (p!= NULL) {
#ifdef debug
            cout << "Process " << this->procs[jobsLoaded].getPID() << " has arrived. Deadlines: " <<
                    p->getDeadline() << " " << this->procs.at(jobsLoaded).getDeadline() << endl;
#endif
            //put currently active process (if we have one) back in the queue in case it needs to be replaced with
            // a process with a shorter deadline. We'll end up pulling it back out if it doesn't
            procQueue.push_back(*p);
        }

        // account for multiple processes arriving at the same time
        while(jobsLoaded < this->procs.size() && this->procs.at(jobsLoaded).getArrival() == timer) {
            if(this->procs.at(jobsLoaded).getDeadline() >= this->procs.at(jobsLoaded).getBurst() + timer){ //process can finish by deadline
                procQueue.push_back(this->procs.at(jobsLoaded));
                jobsLoaded++;
            //process can't finish by deadline
            } else { 
                if(hardSoft == 'h') { //hard real time mode: stop everything
                    hardRealTimeStop = true;
                    cout << "Process " << this->procs.at(jobsLoaded).getPID() << " cancelled. Shutting down." << endl;
                    timer = -1; //forces while loop to end
                }

                jobsLoaded++;
                done.push_back(*p);
                p->setEnd(timer);
            }
        }

        //Order processes by deadline again and make the lowest deadline process active (unless hard real time is stopping RTS)
        if (!hardRealTimeStop && !procQueue.empty()) {
            sort(procQueue.begin(), procQueue.end(), Process::compareDeadline);
            p = &procQueue.front();
            procQueue.pop_front();
        }
    }
}

//printf("Process queue size %d\n", procQueue.size());
//fflush(stdout);  

//Destructor
Rts::~Rts() { }

//Utility
//handy way to print errors

int Rts::getTimeSpent()
    {
     return timer;
    }

void Rts::pushHighestToTop()
    {
             sort(procs.begin(), procs.end(), Process::comparePriorities);
    }

void Rts::callError(const char* words, bool exitApp)
    {
    printf("Rts Error:");
    perror(words);
    if (exitApp)
        exit(1);
    }


