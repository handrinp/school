#ifndef MFQS_H
#define MFQS_H

#include <stdlib.h>
#include <deque>
#include "Process.h"

using namespace std;

class Mfqs {
    public:
        Mfqs(vector<Process> ps);
        ~Mfqs();
        int getTimeQuantum();
        void setTimeQuantum(int tq);
    protected:
        void callError(const char* words, bool exitApp);
    private:
        int tQuant;
        vector<Process> procs;
        vector<deque<Process>> queues;
        int numQueues;
};

#endif // MFQS_H
