#ifndef WHS_H
#define WHS_H

#include "main.h"

class Whs
{
    public:
        Whs(vector<Process> procs);
        ~Whs();
    protected:
        void callError(const char* words, bool exitApp);
    private:
};

#endif // WHS_H
