Lecture date: **2017-09-12**

Objectives
==========
- Provide tour of major OS concepts
- Provide coverage of systems organization

Scheduling
==========
- Not necessarily looking for an efficient algorithm, but a _fair_ algorithm

Kernel
======
- Process Manager
- File Manager
- Memory Manager
- I/O
- OS runs in user mode, or Kernel mode
- OS is an interrupt driven system
- Idle &rarr; Running
- Running &rarr; Wait
- Wait &rarr; Idle

Funny Quotes
------------
- "Whiskey Tango Foxtrot"

