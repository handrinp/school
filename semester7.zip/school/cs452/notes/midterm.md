Chapter 2 Slides
================
- what it does
- what it means to be "an interrupt driven system"
- what a process control block is
- state diagrams:
    1. ready
    2. running
    3. wait
    4. ...
- processes
    - process synchronization
- semaphores
    - classical problems (barbershop problem)
    - binary semaphore (mutex) vs counting semaphore
    - when do you wait? ... signal? ... both?

Schedulers
==========
- everything up through today
- priority
    - priority is priority #
- round robin
    - priority agnostic
- short burst

